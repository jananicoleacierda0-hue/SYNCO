/* SYNCO shell: switches between the two apps (School Hub / WinS Tracker). */
var frames = document.querySelectorAll("iframe");
var buttons = document.querySelectorAll("nav button");

function show(id) {
  frames.forEach(function (f) {
    f.className = f.id === id ? "on" : "";
  });
  buttons.forEach(function (b) {
    b.className = b.dataset.f === id ? "on" : "";
  });
  try {
    sessionStorage.setItem("shell-tab", id);
  } catch (e) {}
}

document.querySelector("nav").onclick = function (e) {
  var b = e.target.closest("button");
  if (b) show(b.dataset.f);
};

var start = "f1";
try {
  start = sessionStorage.getItem("shell-tab") || "f1";
} catch (e) {}
show(start);
