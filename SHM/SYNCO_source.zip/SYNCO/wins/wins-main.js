var G = [
  { k: "dw", q: "May inuming tubig buong linggo", s: "Q1" },
  { k: "hw", q: "Tubig para sa handwashing at CR", s: "Q7", w: 1 },
  { k: "sp", q: "May sabon sa handwashing areas buong linggo", s: "Q35" },
  { k: "tb", q: "May takip na basurahan, naka-segregate", s: "Q16" },
  { k: "cl", q: "Nilinis ang mga CR ngayong linggo", s: "Q14" },
  { k: "gc", q: "Nakolekta ang basura ngayong linggo", s: "Q19" },
  { k: "sw", q: "Walang stagnant water, maayos ang drainage", s: "Q24, Q26" },
  { k: "gh", q: "Nagkaroon ng group handwashing with soap ngayong linggo", s: "Q32" },
  { k: "gt", q: "Nagkaroon ng group toothbrushing with fluoride ngayong linggo", s: "Q38" },
];
var S = { fac: [], days: {}, issues: [] },
  tab = 1,
  cur = wk(iso(new Date())),
  range = "week",
  pw = "all",
  mem = {},
  db = null;
function iso(d) {
  var m = d.getMonth() + 1,
    x = d.getDate();
  return d.getFullYear() + "-" + (m < 10 ? "0" : "") + m + "-" + (x < 10 ? "0" : "") + x;
}
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/"/g, "&quot;");
}
function load() {
  try {
    S = JSON.parse(localStorage.getItem("wins2") || "") || S;
  } catch (e) {}
  S.fac = S.fac || [];
  S.days = S.days || {};
  S.issues = S.issues || [];
}
function save() {
  try {
    localStorage.setItem("wins2", JSON.stringify(S));
  } catch (e) {}
}
function day() {
  return S.days[cur] || (S.days[cur] = { g: {}, f: {} });
}
function idb(cb) {
  if (db) return cb(db);
  try {
    var r = indexedDB.open("wins_photos", 1);
    r.onupgradeneeded = function () {
      r.result.createObjectStore("p");
    };
    r.onsuccess = function () {
      db = r.result;
      cb(db);
    };
    r.onerror = function () {
      cb(null);
    };
  } catch (e) {
    cb(null);
  }
}
function putP(id, d, cb) {
  mem[id] = d;
  idb(function (x) {
    if (!x) return cb();
    try {
      var t = x.transaction("p", "readwrite");
      t.objectStore("p").put(d, id);
      t.oncomplete = cb;
      t.onerror = cb;
    } catch (e) {
      cb();
    }
  });
}
function getP(id, cb) {
  if (mem[id]) return cb(mem[id]);
  idb(function (x) {
    if (!x) return cb(null);
    try {
      var q = x.transaction("p").objectStore("p").get(id);
      q.onsuccess = function () {
        cb(q.result);
      };
      q.onerror = function () {
        cb(null);
      };
    } catch (e) {
      cb(null);
    }
  });
}
function delP(id) {
  delete mem[id];
  idb(function (x) {
    try {
      if (x) x.transaction("p", "readwrite").objectStore("p").delete(id);
    } catch (e) {}
  });
}
function fill() {
  [].forEach.call(document.querySelectorAll("img[data-p]"), function (im) {
    getP(im.getAttribute("data-p"), function (d) {
      if (d) im.src = d;
    });
  });
}
function shrink(file, cb) {
  var fr = new FileReader();
  fr.onload = function () {
    var im = new Image();
    im.onload = function () {
      var m = 900,
        s = Math.min(1, m / Math.max(im.width, im.height)),
        c = document.createElement("canvas");
      c.width = im.width * s;
      c.height = im.height * s;
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
      cb(c.toDataURL("image/jpeg", 0.7));
    };
    im.src = fr.result;
  };
  fr.readAsDataURL(file);
}
function seg(a, id, v, yes, no) {
  return (
    '<div class="seg"><button class="y ' +
    (v === 1 ? "on" : "") +
    '" data-a="' +
    a +
    '" data-i="' +
    id +
    '" data-v="1">' +
    (yes || "Oo") +
    '</button><button class="n ' +
    (v === 0 ? "on" : "") +
    '" data-a="' +
    a +
    '" data-i="' +
    id +
    '" data-v="0">' +
    (no || "Hindi") +
    "</button></div>"
  );
}
function prevWeek() {
  var best = null;
  Object.keys(S.days).forEach(function (d) {
    var X = S.days[d];
    if (
      d < cur &&
      (Object.keys(X.g || {}).length || Object.keys(X.f || {}).length) &&
      (!best || d > best)
    )
      best = d;
  });
  return best;
}
function cseg(k, v) {
  var h = '<div class="seg">';
  for (var n = 0; n <= 5; n++)
    h +=
      '<button class="y ' +
      (v === n ? "on" : "") +
      '" data-a="g" data-i="' +
      k +
      '" data-v="' +
      n +
      '">' +
      n +
      "</button>";
  return h + "</div>";
}
function issuesFor(d, f) {
  return S.issues.filter(function (i) {
    return i.date === d && i.fid === f;
  });
}
function sexL(s) {
  return s === "M" ? "Lalaki" : s === "F" ? "Babae" : "Shared";
}
function viewNow() {
  var D = day(),
    h =
      '<div class="card"><p class="lbl">Linggo (pumili ng kahit anong araw sa linggo)</p><input type="date" id="dt" value="' +
      cur +
      '"><div class="sug">' +
      wl(cur) +
      "</div>" +
      (prevWeek()
        ? '<button class="b p noprint" style="margin-top:8px;width:100%" data-a="cp">\ud83d\udccb Kopyahin ang sagot ng ' +
          wl(prevWeek()) +
          '</button><p class="lbl" style="margin:6px 0 0">Ang mga wala pang sagot lang ang pupunan. Baguhin mo na lang ang nag-iba.</p>'
        : "") +
      "</div>";
  if (!S.fac.length)
    h +=
      '<div class="card">Wala pang nakalistang CR o handwashing facility. Pumunta sa tab na Facilities.</div>';
  var cr = S.fac.filter(function (f) {
      return f.kind === "cr";
    }),
    hw = S.fac.filter(function (f) {
      return f.kind === "hw";
    });
  function block(list, title, q, y, n) {
    if (!list.length) return;
    h += "<h2>" + title + "</h2>";
    list.forEach(function (f) {
      var v = D.f[f.id];
      h +=
        '<div class="card"><div class="row"><div class="q">' +
        esc(f.name) +
        "<small>" +
        (f.kind === "cr"
          ? sexL(f.sex) + " · " + f.seats + " seat"
          : (f.group ? "Group" : "Individual") + " · " + f.outlets + " outlet") +
        " · " +
        q +
        "</small></div>" +
        seg("f", f.id, v, y, n) +
        "</div>";
      if (v === 0) {
        var is = issuesFor(cur, f.id);
        h +=
          '<div class="proof"><input id="n_' +
          f.id +
          '" placeholder="Ano ang problema? (madumi, sira, walang tubig...)"><label class="cam">📷 Kunan ng proof<input type="file" accept="image/*" capture="environment" data-a="ph" data-i="' +
          f.id +
          '"></label> <button class="b" data-a="nt" data-i="' +
          f.id +
          '">Tala lang</button>';
        if (is.length)
          h +=
            '<div class="th">' +
            is
              .map(function (i) {
                return i.photo
                  ? '<img data-p="' + i.photo + '" alt="proof">'
                  : '<span class="tag">' + esc(i.note || "tala") + "</span>";
              })
              .join("") +
            "</div>";
        h += "</div>";
      }
      h += "</div>";
    });
  }
  block(cr, "Mga CR", "Malinis ba buong linggo?", "Malinis", "Madumi");
  block(hw, "Handwashing", "Gumagana (may tubig/sabon) buong linggo?", "Oo", "Hindi");
  h += "<h2>Pangkalahatan</h2>";
  G.forEach(function (g) {
    var v = D.g[g.k];
    h +=
      '<div class="card"><div class="row"><div class="q">' +
      g.q +
      "<small>" +
      g.s +
      "</small></div>" +
      (g.c
        ? cseg(g.k, v)
        : g.w
          ? '<div class="seg"><button class="y ' +
            (v === "24" ? "on" : "") +
            '" data-a="g" data-i="hw" data-v="24">24h araw-araw</button><button class="y ' +
            (v === "p" ? "on" : "") +
            '" data-a="g" data-i="hw" data-v="p">Ilang oras</button><button class="n ' +
            (v === "0" ? "on" : "") +
            '" data-a="g" data-i="hw" data-v="0">Ilang araw</button></div>'
          : seg("g", g.k, v)) +
      "</div></div>";
  });
  return h;
}
function viewFac() {
  var h =
    '<div class="card"><p class="lbl">Magdagdag ng CR (Q8)</p><input id="cn" placeholder="Pangalan (hal. CR Grade 1 Babae)"><div class="g" style="margin-top:8px"><select id="cs"><option value="F">Babae</option><option value="M">Lalaki</option><option value="S">Shared</option></select><input id="cq" type="number" min="1" value="1" placeholder="Ilang toilet seat"></div><button class="b p" data-a="addcr">Idagdag</button></div>';
  h +=
    '<div class="card"><p class="lbl">Magdagdag ng handwashing facility (Q34)</p><input id="hn" placeholder="Pangalan (hal. Handwashing area A)"><div class="g" style="margin-top:8px"><select id="hg"><option value="1">Group</option><option value="0">Individual</option></select><input id="ho" type="number" min="1" value="10" placeholder="Ilang gripo/outlet"></div><button class="b p" data-a="addhw">Idagdag</button></div>';
  S.fac.forEach(function (f) {
    h +=
      '<div class="card"><div class="row"><div class="q">' +
      esc(f.name) +
      "<small>" +
      (f.kind === "cr"
        ? "CR · " + sexL(f.sex) + " · " + f.seats + " seat"
        : "Handwashing · " + (f.group ? "Group" : "Individual") + " · " + f.outlets + " outlet") +
      '</small></div><div class="seg">' +
      (f.kind === "cr"
        ? '<button class="y ' +
          (f.func === false ? "" : "on") +
          '" data-a="fn" data-i="' +
          f.id +
          '" data-v="1">\u2713 Gumagana</button><button class="n ' +
          (f.func === false ? "on" : "") +
          '" data-a="fn" data-i="' +
          f.id +
          '" data-v="0">\u2717 Sira</button>'
        : "") +
      '<button class="b" data-a="del" data-i="' +
      f.id +
      '">Burahin</button></div></div></div>';
  });
  return h;
}
function viewProof() {
  var h =
    '<div class="pr"><h2>WinS Proof of Monitoring — Potrero Elementary School</h2></div><div class="pr">' +
    statsH() +
    '</div><div class="noprint"><button class="b p" data-a="print">\ud83d\udda8 I-print</button> <button class="b p" data-a="pdf">\u2b07 I-download bilang PDF</button></div><h2>Mga isyu at proof</h2>';
  if (!S.issues.length)
    return (
      h +
      '<div class="card">Wala pang naka-log. Lalabas dito ang mga naka-photo kapag may minarkahan kang Madumi o Hindi gumagana.</div>'
    );
  var ws = [];
  S.issues.forEach(function (i) {
    var k = wk(i.date);
    if (ws.indexOf(k) < 0) ws.push(k);
  });
  ws.sort().reverse();
  if (pw !== "all" && ws.indexOf(pw) < 0) pw = "all";
  h +=
    '<div class="card noprint"><p class="lbl">Linggo</p><select id="pw"><option value="all"' +
    (pw === "all" ? " selected" : "") +
    ">Lahat ng linggo</option>" +
    ws
      .map(function (w) {
        return (
          '<option value="' + w + '"' + (pw === w ? " selected" : "") + ">" + wl(w) + "</option>"
        );
      })
      .join("") +
    "</select></div>";
  var lw = "";
  S.issues
    .slice()
    .sort(function (a, b) {
      return a.date < b.date ? 1 : -1;
    })
    .forEach(function (i) {
      var wkk = wk(i.date);
      if (pw !== "all" && pw !== wkk) return;
      if (wkk !== lw) {
        h += "<h2>" + wl(wkk) + "</h2>";
        lw = wkk;
      }
      var f = S.fac.filter(function (x) {
        return x.id === i.fid;
      })[0];
      h +=
        '<div class="card"><div class="row"><div class="q"><b>' +
        esc(f ? f.name : "(nabura na)") +
        "</b><small>" +
        i.date +
        '</small></div><span class="tag ' +
        (i.res ? "ok" : "") +
        '">' +
        (i.res ? "Naayos" : "Bukas pa") +
        "</span></div>" +
        (i.note ? '<p style="margin:8px 0 0">' + esc(i.note) + "</p>" : "") +
        (i.photo ? '<img class="big" data-p="' + i.photo + '" alt="proof">' : "") +
        '<div class="seg noprint" style="margin-top:8px;justify-content:flex-start"><button class="b" data-a="res" data-i="' +
        i.id +
        '">' +
        (i.res ? "Ibalik bilang bukas" : "Markahang naayos") +
        '</button><button class="b" data-a="di" data-i="' +
        i.id +
        '">Burahin</button></div></div>';
    });
  return h;
}
function wl(w) {
  var M = ["Ene", "Peb", "Mar", "Abr", "May", "Hun", "Hul", "Ago", "Set", "Okt", "Nob", "Dis"],
    a = new Date(w + "T00:00:00"),
    b = new Date(a);
  b.setDate(b.getDate() + 6);
  return (
    "Linggo ng " +
    M[a.getMonth()] +
    " " +
    a.getDate() +
    (a.getMonth() !== b.getMonth()
      ? " \u2013 " + M[b.getMonth()] + " " + b.getDate()
      : " \u2013 " + b.getDate()) +
    ", " +
    b.getFullYear()
  );
}
function wk(d) {
  var t = new Date(d + "T00:00:00");
  t.setDate(t.getDate() - ((t.getDay() + 6) % 7));
  return iso(t);
}
function wScore(D) {
  var y = 0,
    t = 0;
  G.forEach(function (g) {
    var v = D.g[g.k];
    if (v === undefined) return;
    t++;
    if (g.w ? v === "24" : v === 1) y++;
  });
  Object.keys(D.f || {}).forEach(function (k) {
    t++;
    if (D.f[k] === 1) y++;
  });
  return t ? Math.round((y / t) * 100) : null;
}
function tl(a) {
  var y = 0,
    t = 0;
  a.forEach(function (v) {
    t++;
    if (v) y++;
  });
  return { y: y, t: t };
}
function statsH() {
  var W = {};
  DK().forEach(function (d) {
    var c = wScore(S.days[d]);
    if (c === null) return;
    var k = wk(d);
    (W[k] = W[k] || []).push(c);
  });
  var ks = Object.keys(W).sort().slice(-8),
    sm2 = function (a) {
      return a.reduce(function (x, y) {
        return x + y;
      }, 0);
    },
    sc = ks.map(function (k) {
      return Math.round(sm2(W[k]) / W[k].length);
    });
  if (!sc.length && !S.fac.length && !S.issues.length) return "";
  var P = Object.keys(S.days)
      .filter(function (d) {
        return fmo ? d.slice(0, 7) === fmo : wk(d) === cur;
      })
      .sort(),
    per = fmo ? mon(fmo) : wl(cur).replace("Linggo ng ", "Linggo: ");
  var M = {};
  P.forEach(function (d) {
    var k = wk(d),
      X = S.days[d];
    M[k] = M[k] || { g: {}, f: {} };
    Object.keys(X.g || {}).forEach(function (q) {
      M[k].g[q] = X.g[q];
    });
    Object.keys(X.f || {}).forEach(function (q) {
      M[k].f[q] = X.f[q];
    });
  });
  var td = iso(new Date()),
    exp = 0;
  if (fmo) {
    var E = {},
      y = +fmo.slice(0, 4),
      mo = +fmo.slice(5, 7) - 1,
      dt = new Date(y, mo, 1);
    while (dt.getMonth() === mo) {
      if (iso(dt) <= td) E[wk(iso(dt))] = 1;
      dt.setDate(dt.getDate() + 1);
    }
    exp = Object.keys(E).length;
  } else exp = cur <= td ? 1 : 0;
  var nW = Math.max(1, exp),
    hwf = S.fac.filter(function (f) {
      return f.kind === "hw";
    }),
    ansC = 0,
    wa = [0, 0],
    ha = [0, 0];
  Object.keys(M).forEach(function (k) {
    var g = M[k].g,
      f = M[k].f;
    G.forEach(function (q) {
      if (g[q.k] !== undefined) ansC++;
    });
    S.fac.forEach(function (x) {
      if (f[x.id] !== undefined) ansC++;
    });
    if (g.dw !== undefined) wa[g.dw === 1 ? 0 : 1]++;
    if (g.hw !== undefined) wa[g.hw === "24" ? 0 : 1]++;
    if (g.sp !== undefined) ha[g.sp === 1 ? 0 : 1]++;
    if (g.gh !== undefined) ha[g.gh === 1 ? 0 : 1]++;
    hwf.forEach(function (x) {
      if (f[x.id] !== undefined) ha[f[x.id] === 1 ? 0 : 1]++;
    });
  });
  var Rwat = 2 * nW,
    Rhw = (2 + hwf.length) * nW,
    Rall = (G.length + S.fac.length) * nW,
    wu = Math.max(0, Rwat - wa[0] - wa[1]),
    hu = Math.max(0, Rhw - ha[0] - ha[1]);
  function cnt(a, u) {
    return a[0] + " OK \u00b7 " + a[1] + " hindi OK \u00b7 " + u + " walang sagot";
  }
  var cr = S.fac.filter(function (f) {
      return f.kind === "cr";
    }),
    fn = cr.filter(function (f) {
      return f.func !== false;
    }).length,
    op = S.issues.filter(function (i) {
      return !i.res;
    }).length;
  var rs = S.issues.filter(function (i) {
    var d = i.res ? i.rd || i.date : "";
    return d && (fmo ? d.slice(0, 7) === fmo : wk(d) === cur);
  }).length;
  var ND = "No data available",
    WN = "var(--no)";
  function tile(n, l, sub, c, sm) {
    return (
      '<div class="tile"><b style="' +
      (c ? "color:" + c + ";" : "") +
      (sm ? "font-size:15px;line-height:30px" : "") +
      '">' +
      n +
      "</b><span>" +
      l +
      "</span><small>" +
      sub +
      "</small></div>"
    );
  }
  var h =
    '<h2>\ud83d\udcca Statistics</h2><p class="lbl" style="margin:0 0 6px">' +
    per +
    '</p><div class="tiles">' +
    (wa[0] + wa[1]
      ? tile(
          wu > 0
            ? "Incomplete"
            : wa[0] === Rwat
              ? "Available"
              : wa[0] === 0
                ? "Not Available"
                : "Partially Available",
          "Water Availability",
          cnt(wa, wu) + " (Q1, Q7)",
          wa[1] ? WN : "",
          1,
        )
      : tile(ND, "Water Availability", "Sagutan ang Q1 at Q7", "", 1)) +
    (ha[0] + ha[1]
      ? tile(
          hu > 0 ? ha[0] + "/" + Rhw + " OK" : Math.round((ha[0] / Rhw) * 100) + "%",
          "Handwashing Compliance",
          cnt(ha, hu) + (hwf.length ? "" : " \u00b7 Q34 N/A"),
          ha[1] ? WN : "",
        )
      : tile(ND, "Handwashing Compliance", "Q32, Q34, Q35", "", 1)) +
    (fmo || exp
      ? tile(
          ansC + "/" + Rall,
          "Response Completeness",
          Rall - ansC > 0 ? Rall - ansC + " tanong ang walang sagot pa" : "kumpleto lahat ng sagot",
          "",
        )
      : tile(ND, "Response Completeness", "Hindi pa nagsisimula ang linggong ito", "", 1)) +
    (cr.length
      ? tile(fn + "/" + cr.length, "CR na gumagana", "mula sa Facilities", fn < cr.length ? WN : "")
      : tile(ND, "CR na gumagana", "Magdagdag sa Facilities", "", 1)) +
    tile(op, "Pending Issues", "hindi pa naayos", op ? WN : "") +
    tile(rs, "Resolved Issues", "naayos " + (fmo ? "ngayong buwan" : "ngayong linggo"), "") +
    "</div>";
  if (sc.length)
    h +=
      '<div class="card"><p class="lbl">Weekly WinS Compliance Trend (% ng Oo / Malinis sa mga nasagot)</p><div class="chart">' +
      sc
        .map(function (v, i) {
          return (
            '<div class="col"><em>' +
            v +
            '%</em><div class="bw"><i style="height:' +
            v +
            "%;background:" +
            (v >= 80 ? "var(--ac)" : v >= 50 ? "#e0a030" : "var(--no)") +
            '"></i></div><small>' +
            wl(ks[i]).split(" \u2013")[0].slice(10) +
            "</small></div>"
          );
        })
        .join("") +
      "</div>" +
      (sc.length < 2
        ? '<p class="lbl" style="margin:8px 0 0">Isang linggo pa lang ang may sagot. Kailangan pa ng mas maraming linggo ng monitoring para makita ang trend.</p>'
        : "") +
      "</div>";
  else
    h +=
      '<div class="card"><p class="lbl" style="margin:0">Weekly WinS Compliance Trend: ' +
      ND +
      "</p></div>";
  return h;
}
function viewSum() {
  var crs = S.fac.filter(function (f) {
      return f.kind === "cr";
    }),
    hws = S.fac.filter(function (f) {
      return f.kind === "hw";
    });
  function n(sex, fn) {
    return crs
      .filter(function (f) {
        return f.sex === sex && (f.func !== false) === fn;
      })
      .reduce(function (a, f) {
        return a + Number(f.seats || 0);
      }, 0);
  }
  var h =
    '<div class="noprint"><button class="b p" data-a="print">\ud83d\udda8 I-print</button> <button class="b p" data-a="pdf">\u2b07 I-download bilang PDF</button></div>' +
    statsH() +
    '<h2>Q8 · Toilet seats</h2><div class="card"><table><tr><th></th><th>Lalaki</th><th>Babae</th><th>Shared</th><th>Total</th></tr>';
  [
    [true, "Functional"],
    [false, "Not functional"],
  ].forEach(function (r) {
    var a = n("M", r[0]),
      b = n("F", r[0]),
      c = n("S", r[0]);
    h +=
      "<tr><th>" +
      r[1] +
      "</th><td>" +
      a +
      "</td><td>" +
      b +
      "</td><td>" +
      c +
      "</td><td>" +
      (a + b + c) +
      "</td></tr>";
  });
  h +=
    '</table></div><h2>Q34 · Handwashing facilities</h2><div class="card"><table><tr><th></th><th>Ilan</th><th>Total outlets</th></tr>';
  [
    [0, "Individual"],
    [1, "Group"],
  ].forEach(function (r) {
    var l = hws.filter(function (f) {
      return !!f.group === !!r[0];
    });
    h +=
      "<tr><th>" +
      r[1] +
      "</th><td>" +
      l.length +
      "</td><td>" +
      l.reduce(function (a, f) {
        return a + Number(f.outlets || 0);
      }, 0) +
      "</td></tr>";
  });
  h +=
    '</table></div><h2>Mga linggo</h2><div class="card"><p class="lbl">Saklaw</p><select id="rg"><option value="week"' +
    (range === "week" ? " selected" : "") +
    '>Linggong ito</option><option value="month"' +
    (range === "month" ? " selected" : "") +
    '>Buwang ito</option><option value="all"' +
    (range === "all" ? " selected" : "") +
    ">Lahat</option></select></div>";
  var now = iso(new Date()),
    days = Object.keys(S.days)
      .filter(function (d) {
        return range === "week"
          ? wk(d) === wk(now)
          : range === "month"
            ? d.slice(0, 7) === now.slice(0, 7)
            : true;
      })
      .sort();
  if (!days.length) return h + '<div class="card">Wala pang naka-log sa saklaw na ito.</div>';
  var wks = {};
  days.forEach(function (d) {
    wks[wk(d)] = 1;
  });
  var nw = Math.max(1, Object.keys(wks).length);
  h +=
    '<div class="prog">' +
    nw +
    " linggo · " +
    S.issues.filter(function (i) {
      return !i.res;
    }).length +
    " isyung bukas pa</div>";
  function card(q, s, yes, tot, sug, w) {
    var p = tot ? Math.round((yes / tot) * 100) : 0;
    return (
      '<div class="card"><div class="row"><div class="q">' +
      q +
      "<small>" +
      s +
      "</small></div><b>" +
      p +
      '%</b></div><div class="bar"><i style="width:' +
      p +
      '%"></i></div>' +
      (sug ? '<div class="sug">' + sug + "</div>" : "") +
      "</div>"
    );
  }
  var cy = 0,
    ct = 0;
  days.forEach(function (d) {
    var v = S.days[d].f || {},
      ids = crs
        .map(function (f) {
          return v[f.id];
        })
        .filter(function (x) {
          return x !== undefined;
        });
    if (ids.length) {
      ct++;
      if (ids.indexOf(0) < 0) cy++;
    }
  });
  var pw = (cy / nw).toFixed(1),
    pc = ct ? (cy / ct) * 100 : 0;
  h += card("Malinis ang lahat ng CR", "mga linggong walang Madumi", cy, ct, "");
  G.forEach(function (g) {
    if (g.c) {
      var vs = [];
      days.forEach(function (d) {
        var v = S.days[d].g[g.k];
        if (typeof v === "number") vs.push(v);
      });
      var av = vs.length
          ? vs.reduce(function (a, b) {
              return a + b;
            }, 0) / vs.length
          : 0,
        sg =
          g.k === "cl"
            ? av >= 4.5
              ? "Daily"
              : av >= 2
                ? "At least twice a week"
                : av >= 1
                  ? "Once a week"
                  : "Less than once a week"
            : g.k === "gc"
              ? av >= 4.5
                ? "Daily"
                : av >= 2
                  ? "2-3 times a week"
                  : av >= 1
                    ? "Once a week"
                    : av > 0
                      ? "Less than once a week"
                      : "No Collection"
              : "mga " + Math.round(av) + " beses kada linggo";
      h +=
        '<div class="card"><div class="row"><div class="q">' +
        g.q +
        "<small>" +
        g.s +
        "</small></div><b>" +
        (vs.length ? av.toFixed(1) + "\u00d7" : "\u2014") +
        '</b></div><div class="bar"><i style="width:' +
        Math.min(100, (av / 5) * 100) +
        '%"></i></div>' +
        (vs.length ? '<div class="sug">' + g.s + ": " + sg + "</div>" : "") +
        "</div>";
      return;
    }
    var y = 0,
      t = 0,
      w = 0,
      p = 0;
    days.forEach(function (d) {
      var v = S.days[d].g[g.k];
      if (v === undefined) return;
      t++;
      if (g.w) {
        if (v === "24") y++;
        else if (v === "p") p++;
      } else if (v === 1) y++;
    });
    var pw2 = (y / nw).toFixed(1),
      pc2 = t ? (y / t) * 100 : 0,
      s = "";
    if (g.k === "dw") s = pc2 === 100 ? "Q1: All the time" : "Q1: Yes, but supply is not regular";
    else if (g.k === "sp") s = "Q35: " + (pc2 >= 90 ? "Yes" : "No") + " (regular supply)";
    else if (g.w)
      s = "24h araw-araw: " + y + " · Ilang oras: " + p + " · Ilang araw: " + (t - y - p);
    h += card(g.q, g.s, y, t, s);
  });
  return (
    h +
    '<div class="prog">Suhestiyon lang ito mula sa mga log. Ikaw pa rin ang magpapasya sa isasagot sa form.</div>'
  );
}
function draw() {
  var v = document.getElementById("v");
  v.innerHTML =
    tab === 1
      ? viewNow()
      : tab === 2
        ? viewFac()
        : tab === 3
          ? viewProof()
          : tab === 5
            ? viewForm()
            : viewSum();
  [].forEach.call(document.querySelectorAll(".tabs button"), function (b) {
    b.className = +b.getAttribute("data-t") === tab ? "on" : "";
  });
  fill();
}
function addIssue(fid, photo) {
  var el = document.getElementById("n_" + fid);
  S.issues.push({
    id: uid(),
    date: cur,
    fid: fid,
    note: el ? el.value : "",
    photo: photo || null,
    res: false,
  });
  save();
  draw();
}
document.addEventListener("click", function (e) {
  var t = e.target.closest(".tabs button");
  if (t) {
    tab = +t.getAttribute("data-t");
    draw();
    return;
  }
  var b = e.target.closest("button[data-a]");
  if (!b) return;
  var a = b.getAttribute("data-a"),
    i = b.getAttribute("data-i"),
    v = b.getAttribute("data-v");
  if (a === "f") {
    var D = day(),
      n = +v;
    if (D.f[i] === n) delete D.f[i];
    else D.f[i] = n;
    save();
    draw();
  } else if (a === "g") {
    var D2 = day(),
      val = i === "hw" ? v : +v;
    if (D2.g[i] === val) delete D2.g[i];
    else D2.g[i] = val;
    save();
    draw();
  } else if (a === "nt") {
    addIssue(i, null);
  } else if (a === "addcr") {
    var nm = document.getElementById("cn").value.trim();
    if (!nm) return;
    S.fac.push({
      id: uid(),
      kind: "cr",
      name: nm,
      sex: document.getElementById("cs").value,
      seats: +document.getElementById("cq").value || 1,
      func: true,
    });
    save();
    draw();
  } else if (a === "addhw") {
    var hn = document.getElementById("hn").value.trim();
    if (!hn) return;
    S.fac.push({
      id: uid(),
      kind: "hw",
      name: hn,
      group: document.getElementById("hg").value === "1",
      outlets: +document.getElementById("ho").value || 1,
    });
    save();
    draw();
  } else if (a === "fn") {
    S.fac.forEach(function (f) {
      if (f.id === i) f.func = v === "1";
    });
    save();
    draw();
  } else if (a === "del") {
    S.fac = S.fac.filter(function (f) {
      return f.id !== i;
    });
    save();
    draw();
  } else if (a === "res") {
    S.issues.forEach(function (x) {
      if (x.id === i) x.res = !x.res;
      x.rd = x.res ? iso(new Date()) : null;
    });
    save();
    draw();
  } else if (a === "di") {
    S.issues = S.issues.filter(function (x) {
      if (x.id === i && x.photo) delName(x.photo);
      return x.id !== i;
    });
    save();
    draw();
  } else if (a === "cp") {
    var pv = prevWeek();
    if (pv) {
      var P = S.days[pv],
        D3 = day();
      Object.keys(P.g || {}).forEach(function (k) {
        if (D3.g[k] === undefined) D3.g[k] = P.g[k];
      });
      Object.keys(P.f || {}).forEach(function (k) {
        if (
          D3.f[k] === undefined &&
          S.fac.some(function (x) {
            return x.id === k;
          })
        )
          D3.f[k] = P.f[k];
      });
      save();
      draw();
    }
  } else if (a === "print") {
    try {
      window.print();
    } catch (er) {}
  } else if (a === "pdf") {
    var fb = function () {
      if (!window._pt) {
        window._pt = 1;
        alert(
          'Walang internet kaya hindi ma-download nang diretso. Sa Printer, piliin ang "Save as PDF", tapos pindutin ang Save.',
        );
      }
      try {
        window.print();
      } catch (er) {}
    };
    if (!window.html2pdf) {
      fb();
    } else {
      var bx = document.createElement("div");
      bx.className = "pdfx";
      bx.innerHTML =
        '<div class="pdfh"><b>WinS Monitoring Tracker</b><span>Potrero Elementary School</span></div>' +
        document.getElementById("v").innerHTML;
      var nm =
        "WinS_" +
        (tab === 5
          ? fper === "m"
            ? "Monthly_" + (fmv || cur.slice(0, 7))
            : "Weekly_" + cur
          : tab === 3
            ? "Proof_" + cur
            : "Buod_" + cur) +
        ".pdf";
      window
        .html2pdf()
        .set({
          margin: 8,
          filename: nm,
          image: { type: "jpeg", quality: 0.95 },
          html2canvas: { scale: 2, backgroundColor: "#fff" },
          jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
          pagebreak: { mode: ["css", "legacy"], avoid: [".fr", ".tile", ".card", ".fs"] },
        })
        .from(bx)
        .save()
        .then(
          function () {
            bx.remove();
          },
          function () {
            bx.remove();
            fb();
          },
        );
    }
  }
});
function delName(p) {
  delP(p);
}
document.addEventListener("change", function (e) {
  var t = e.target;
  if (t.id === "dt") {
    cur = wk(t.value || cur);
    draw();
  } else if (t.id === "rg") {
    range = t.value;
    draw();
  } else if (t.id === "pw") {
    pw = t.value;
    draw();
  } else if (t.getAttribute("data-a") === "ph" && t.files && t.files[0]) {
    var fid = t.getAttribute("data-i");
    shrink(t.files[0], function (d) {
      var pid = uid();
      putP(pid, d, function () {
        addIssue(fid, pid);
      });
    });
  }
});
load();
S.form = S.form || { h: {}, a: {} };
draw();
