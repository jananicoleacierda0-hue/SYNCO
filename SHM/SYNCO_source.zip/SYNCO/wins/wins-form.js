var fm = "e",
  fper = "w",
  fmv = "",
  fmo = "";
var HD = {
  sy: "2026 - 2027",
  lv: "Elementary",
  sn: "Potrero Elementary School",
  id: "136848",
  di: "IV",
  dv: "Malabon City",
  ad: "4 Pinagtipunan Circle, Brgy. Potrero, Malabon City",
  hd: "Elizabeth C. Aquino",
  s1m: "482",
  s1f: "474",
  s2m: "501",
  s2f: "455",
};
var YN = function (n, q) {
  return { n: n, t: "yn", q: q };
};
var FQ = [
  { s: "B. Water Access" },
  {
    n: "1",
    t: "one",
    q: "Does the school provide drinking water?",
    o: ["All the time", "Yes, but supply is not regular", "No drinking water in the school"],
  },
  YN("2", "Is the drinking water provided by the school for free?"),
  YN(
    "3",
    "Does the school coordinate with the LGU or water district to test the quality of water?",
  ),
  {
    n: "4",
    t: "num",
    q: "How many times was the quality of water tested in the current calendar year?",
  },
  YN("5", "Did the test result show that water is safe for drinking?"),
  {
    n: "6",
    t: "many",
    q: "What other mechanisms are used to ensure that drinking water in school is safe?",
    o: [
      "Teachers ask the learners to bring their own drinking water to school",
      "If from a refilling station, the school requires a water quality certificate",
      "Water from an accessible water source is boiled",
      "Water from an accessible water source is filtered",
      "Others",
    ],
  },
  {
    n: "7",
    t: "one",
    q: "In the previous week, how often is water for daily handwashing and cleaning of toilets available in the school regardless of source?",
    o: [
      "Available only on certain days of the week",
      "Available daily but only in certain hours",
      "Available daily for 24 hours",
    ],
  },
  { s: "C. Sanitation" },
  {
    n: "8",
    t: "t8",
    q: "How many toilet seats are available for children in the school? (galing sa Facilities)",
  },
  YN("9a", "Are all functional toilets secure, private and have door with lock?"),
  YN(
    "9b",
    "Do all functional toilets have lighting (includes natural light or alternative sources)?",
  ),
  YN("9c", "Do all functional toilets have adequate ventilation?"),
  YN(
    "10",
    "Do all exclusively female toilets have wrapping materials and trash bins for used sanitary pads?",
  ),
  {
    n: "11",
    t: "num",
    q: "How many exclusively female toilets have a washing facility inside the toilet?",
  },
  YN("12", "Are detached toilets within view of school building and people?"),
  YN(
    "13",
    "Are there toilet/s designed for persons with limited mobility (ramp, railing, adequate space for a wheelchair)?",
  ),
  {
    n: "14",
    t: "one",
    q: "How often is the sanitation facilities cleaned?",
    o: ["Daily", "Once a week", "Less than once a week", "At least twice a week"],
  },
  YN("15", "Does the school burn its waste?"),
  {
    n: "16",
    t: "many",
    q: "Are segregated trash bins with cover available in the following areas?",
    o: [
      "Classrooms",
      "Toilets",
      "Canteens",
      "Offices",
      "Clinics",
      "Play Areas",
      "Gardens",
      "Hallways",
      "Gyms/Stage",
    ],
  },
  YN("17", "Are the students segregating their solid waste properly?"),
  YN(
    "18",
    "Does the school have policies/sanctions which promote the practice of solid waste segregation?",
  ),
  {
    n: "19",
    t: "one",
    q: "How regular is garbage being collected from the school?",
    o: ["Daily", "Once a week", "2-3 times a week", "Less than once a week", "No Collection"],
  },
  YN("20", "Does the school have a compost pit for biodegradable waste?"),
  YN("21", "Does the school have a refuse pit for non-biodegradable waste?"),
  YN("22", "Does the school have a materials recovery facility (MRF)?"),
  YN("23", "Do all toilets in the school have functional septic tank/s?"),
  YN(
    "24",
    "Does the school have a functional drainage from the kitchen and all wash areas to ensure that there is no stagnant water?",
  ),
  YN("25", "In the past year, did the school experience any floods?"),
  {
    n: "26",
    t: "one",
    q: "Did the school adopt the following mechanisms to address stagnant water?",
    o: [
      "Pumping out of water",
      "Filling of stagnant water",
      "Soak pit",
      "Treatment of stagnant water to prevent breeding of mosquitoes",
      "Not applicable (e.g., no stagnant water because of sandy soil)",
    ],
  },
  YN("27", "Does the school have a canteen?"),
  YN("28", "Does the school canteen have a sanitary permit?"),
  {
    n: "29",
    t: "many",
    q: "Do food handlers practice the following food safety measures?",
    o: [
      "Wearing of hairnet, gloves, masks and apron",
      "Handwashing",
      "Separate the storage of dry and wet food materials",
    ],
  },
  { n: "30", t: "ans", q: "Have all food handlers been oriented on food safety measures?" },
  { n: "31", t: "ans", q: "Do all food handlers in the school have health certificates?" },
  { s: "D. Hygiene" },
  {
    n: "32",
    t: "num",
    q: "How many times in a week is supervised group handwashing with soap conducted for all children? (0 if not done)",
  },
  {
    n: "33",
    t: "many",
    q: "What is the extent of student participation in supervising group handwashing?",
    o: [
      "Students are participants supervised by teachers",
      "There are students who assist teachers in supervising handwashing activities",
      "There are students assigned to lead handwashing activities",
    ],
  },
  {
    n: "34",
    t: "t34",
    q: "How many handwashing facilities are available in your school? (galing sa Facilities)",
  },
  YN("35", "Is there a regular supply of soap for handwashing?"),
  {
    n: "36",
    t: "many",
    q: "Are handwashing facilities available in the following areas?",
    o: [
      "Classrooms",
      "Toilets",
      "Canteen/Eating Areas",
      "Play areas",
      "Agricultural areas (e.g., Gulayan, livestock area)",
      "Clinics",
      "Laboratories",
    ],
  },
  {
    n: "37",
    t: "many",
    q: "Do children perform individual handwashing during the following times?",
    o: [
      "Before meals/eating/handling food",
      "After using the toilet",
      "After handling soil and animals",
      "After cleaning activities/handling garbage",
      "After playing",
    ],
  },
  {
    n: "38",
    t: "num",
    q: "How many times in a week is supervised group toothbrushing with fluoride conducted for all children? (0 if not done)",
  },
  {
    n: "39",
    t: "many",
    q: "What is the extent of student participation in supervising group toothbrushing?",
    o: [
      "Students are participants supervised by teachers",
      "Students assist teachers in supervising toothbrushing activities",
      "Students are assigned to lead toothbrushing activities",
    ],
  },
  YN(
    "40",
    "For elementary schools, is there a regular supply of toothbrush and toothpaste for toothbrushing?",
  ),
  {
    n: "41",
    t: "many",
    q: "Are the repair and maintenance requirements for WASH facilities reflected in the following?",
    o: ["School improvement plan (SIP)", "Annual improvement plan (AIP)"],
  },
  {
    n: "42",
    t: "g",
    q: "What are the sources of funds for WASH facilities and supplies?",
    r: [
      "Soap",
      "Toothbrush",
      "Toothpaste",
      "Cleaning materials/supplies",
      "Repair and maintenance (labor/spare parts)",
    ],
    c: [
      "School MOOE",
      "Private/Individual Donations",
      "PTA Funds",
      "LGU Funds",
      "Voluntary Donations from Internal Staff",
      "Children Bring Their Own",
    ],
    x: ["4-5"],
  },
  {
    n: "43",
    t: "many",
    q: "Where can learners avail of sanitary pads?",
    o: [
      "School Canteen",
      "School Clinic",
      "Guidance Office",
      "Class adviser/teacher Laboratories",
      "Others",
    ],
  },
  YN(
    "44",
    "Is there information on proper disposal of sanitary napkins in the girls\u2019 toilet?",
  ),
  YN("45", "Are there DepEd Approved Instructional materials on Menstrual Health for Teachers?"),
  YN("46", "Are there DepEd Approved IEC materials on Menstrual Health for Students?"),
  YN("47", "Is there a designated rest space for girls with menstrual discomfort?"),
  { s: "E. Deworming" },
  YN("48", "Is deworming done semi-annually?"),
  { n: "49", t: "num", q: "What is the total number of students dewormed?" },
  { s: "F. Health Education" },
  {
    n: "50",
    t: "g",
    q: "Which areas have IEC materials for WASH in Schools (WinS)?",
    r: [
      "Bulletin board",
      "Classrooms",
      "Toilets",
      "Handwashing facilities",
      "Canteen/Eating areas",
    ],
    c: ["Hygiene", "Menstrual Health Management", "Sanitation", "Food Safety"],
    x: ["3-1", "4-1"],
  },
  YN("51", "Are there organized structures (e.g., TWGs, student clubs) to promote WinS?"),
  YN("52", "Is WinS a part of INSET?"),
  YN("53", "Are learning materials available for teaching WinS?"),
  YN("54", "Is WinS being advocated in the General PTA assembly?"),
  YN(
    "55",
    "Are there planned and organized activities for advocating WinS to parents/stakeholders?",
  ),
  YN("56", "Is WinS part of the co/extra-curricular program for students?"),
];
function hv(k) {
  var v = S.form.h[k];
  return v !== undefined ? v : HD[k] || "";
}
function inv() {
  var c = S.fac.filter(function (f) {
      return f.kind === "cr";
    }),
    w = S.fac.filter(function (f) {
      return f.kind === "hw";
    });
  function n(s, ok) {
    return c
      .filter(function (f) {
        return f.sex === s && (f.func !== false) === !!ok;
      })
      .reduce(function (a, f) {
        return a + Number(f.seats || 0);
      }, 0);
  }
  function g(x) {
    var l = w.filter(function (f) {
      return !!f.group === x;
    });
    return [
      l.length,
      l.reduce(function (a, f) {
        return a + Number(f.outlets || 0);
      }, 0),
    ];
  }
  return {
    f: [n("M", 1), n("F", 1), n("S", 1)],
    nf: [n("M", 0), n("F", 0), n("S", 0)],
    i: g(false),
    g: g(true),
  };
}
function st(k, w) {
  var y = 0,
    t = 0,
    ws = {};
  DK().forEach(function (d) {
    ws[wk(d)] = 1;
    var v = S.days[d].g[k];
    if (v === undefined) return;
    t++;
    if (w ? v === "24" : v === 1) y++;
  });
  return { t: t, pc: t ? (y / t) * 100 : 0, pw: y / Math.max(1, Object.keys(ws).length) };
}
function stCl() {
  var cy = 0,
    ct = 0,
    ws = {},
    c = S.fac.filter(function (f) {
      return f.kind === "cr";
    });
  DK().forEach(function (d) {
    ws[wk(d)] = 1;
    var v = S.days[d].f || {},
      a = c
        .map(function (f) {
          return v[f.id];
        })
        .filter(function (x) {
          return x !== undefined;
        });
    if (a.length) {
      ct++;
      if (a.indexOf(0) < 0) cy++;
    }
  });
  return { t: ct, pc: ct ? (cy / ct) * 100 : 0, pw: cy / Math.max(1, Object.keys(ws).length) };
}
function sm(k) {
  var t = 0,
    x = 0;
  DK().forEach(function (d) {
    var v = S.days[d].g[k];
    if (typeof v !== "number") return;
    t++;
    x += v;
  });
  return { t: t, a: t ? x / t : 0 };
}
function SG(n) {
  var s;
  if (n === "1") {
    s = st("dw");
    return s.t ? (s.pc === 100 ? 0 : 1) : undefined;
  }
  if (n === "7") {
    s = st("hw", 1);
    return s.t ? (s.pc === 100 ? 2 : 1) : undefined;
  }
  if (n === "35") {
    s = st("sp");
    return s.t ? (s.pc >= 90 ? 1 : 0) : undefined;
  }
}
function gk(q, r, c) {
  return (S.form.a[q.n] || {})[r + "-" + c];
}
function txt(q, v) {
  var I = inv();
  if (q.t === "yn") return v === 1 ? "Yes" : v === 0 ? "No" : "\u2014";
  if (q.t === "ans") return { A: "All", S: "Some", N: "None" }[v] || "\u2014";
  if (q.t === "one") return v === undefined ? "\u2014" : q.o[v];
  if (q.t === "many")
    return v && v.length
      ? v
          .map(function (i) {
            return q.o[i];
          })
          .join("; ")
      : "\u2014";
  if (q.t === "num") return v === undefined ? "\u2014" : String(v);
  if (q.t === "t8") {
    function s(a) {
      return "M " + a[0] + ", F " + a[1] + ", Shared " + a[2] + ", Total " + (a[0] + a[1] + a[2]);
    }
    return "Functional: " + s(I.f) + " | Not functional: " + s(I.nf);
  }
  if (q.t === "t34")
    return (
      "Individual: " +
      I.i[0] +
      " facilities, " +
      I.i[1] +
      " outlets | Group: " +
      I.g[0] +
      " facilities, " +
      I.g[1] +
      " outlets"
    );
  if (q.t === "g") {
    return q.r
      .map(function (r, ri) {
        var l = q.c.filter(function (c, ci) {
          return gk(q, ri, ci);
        });
        return r + ": " + (l.length ? l.join(", ") : "\u2014");
      })
      .join(" | ");
  }
}
function cell(q, ri, ci) {
  if (q.x.indexOf(ri + "-" + ci) > -1 || (q.n === "42" && ri === 4 && ci === 5))
    return '<td style="background:var(--ln)"></td>';
  return (
    '<td><button class="b ' +
    (gk(q, ri, ci) ? "p" : "") +
    '" data-a="fc" data-q="' +
    q.n +
    '" data-r="' +
    ri +
    '" data-c="' +
    ci +
    '">' +
    (gk(q, ri, ci) ? "\u2713" : "\u00a0") +
    "</button></td>"
  );
}
function qH(q) {
  var a = S.form.a[q.n],
    h = '<div class="card"><div class="q"><b>' + q.n + ".</b> " + q.q + "</div>",
    s = SG(q.n),
    k,
    i;
  if (a === undefined && s !== undefined)
    h +=
      '<div class="sug">Mungkahi mula sa tracker: ' +
      esc(txt(q, s)) +
      ' <button class="b" data-a="fu" data-q="' +
      q.n +
      '" data-v="' +
      s +
      '">Gamitin</button></div>';
  if (q.t === "yn")
    h +=
      '<div class="seg" style="justify-content:flex-start;margin-top:8px">' +
      seg2(q, a, [
        [1, "Yes"],
        [0, "No"],
      ]) +
      "</div>";
  else if (q.t === "ans")
    h +=
      '<div class="seg" style="justify-content:flex-start;margin-top:8px">' +
      seg2(q, a, [
        ["A", "All"],
        ["S", "Some"],
        ["N", "None"],
      ]) +
      "</div>";
  else if (q.t === "one") {
    h += '<div style="margin-top:8px">';
    q.o.forEach(function (o, i) {
      h +=
        '<button class="b ob ' +
        (a === i ? "p" : "") +
        '" data-a="fa" data-q="' +
        q.n +
        '" data-v="' +
        i +
        '">' +
        esc(o) +
        "</button>";
    });
    h += "</div>";
  } else if (q.t === "many") {
    h += '<div style="margin-top:8px">';
    q.o.forEach(function (o, i) {
      h +=
        '<button class="b ob ' +
        ((a || []).indexOf(i) > -1 ? "p" : "") +
        '" data-a="fm" data-q="' +
        q.n +
        '" data-v="' +
        i +
        '">' +
        esc(o) +
        "</button>";
    });
    h += "</div>";
  } else if (q.t === "num")
    h +=
      '<input type="number" min="0" data-fq="' +
      q.n +
      '" value="' +
      (a === undefined ? "" : a) +
      '" style="margin-top:8px;width:120px">';
  else if (q.t === "g") {
    h +=
      '<div style="overflow-x:auto;margin-top:8px"><table><tr><th></th>' +
      q.c
        .map(function (c) {
          return "<th>" + c + "</th>";
        })
        .join("") +
      "</tr>" +
      q.r
        .map(function (r, ri) {
          return (
            "<tr><th>" +
            r +
            "</th>" +
            q.c
              .map(function (c, ci) {
                return cell(q, ri, ci);
              })
              .join("") +
            "</tr>"
          );
        })
        .join("") +
      "</table></div>";
  } else h += '<div class="sug" style="margin-top:8px">' + esc(txt(q)) + "</div>";
  return h + "</div>";
}
function seg2(q, a, o) {
  return o
    .map(function (x) {
      return (
        '<button class="b ' +
        (a === x[0] ? "p" : "") +
        '" data-a="fa" data-q="' +
        q.n +
        '" data-v="' +
        x[0] +
        '">' +
        x[1] +
        "</button>"
      );
    })
    .join("");
}
function fi(k, l, t) {
  return (
    '<div><p class="lbl">' +
    l +
    '</p><input data-fh="' +
    k +
    '" ' +
    (t || "") +
    ' value="' +
    esc(hv(k)) +
    '"></div>'
  );
}
function formEdit() {
  var h =
    '<h2>A. School Profile</h2><div class="card"><div class="g">' +
    fi("dt", "Date", 'type="date"') +
    fi("sy", "School Year") +
    '</div><div class="seg" style="justify-content:flex-start;margin-bottom:8px"><button class="b ' +
    (hv("lv") === "Elementary" ? "p" : "") +
    '" data-a="fl" data-v="Elementary">Elementary</button><button class="b ' +
    (hv("lv") === "Secondary" ? "p" : "") +
    '" data-a="fl" data-v="Secondary">Secondary</button></div><div class="g">' +
    fi("sn", "School Name") +
    fi("id", "School ID") +
    fi("di", "District") +
    fi("dv", "Division") +
    fi("hd", "Name of School Head") +
    fi("ct", "Contact No.") +
    "</div>" +
    fi("ad", "Complete School Address") +
    '<p class="lbl" style="margin-top:10px">Total Enrolment</p><div class="g">' +
    fi("s1m", "Shift 1 Male", 'type="number"') +
    fi("s1f", "Shift 1 Female", 'type="number"') +
    fi("s2m", "Shift 2 Male", 'type="number"') +
    fi("s2f", "Shift 2 Female", 'type="number"') +
    fi("s3m", "Shift 3 Male", 'type="number"') +
    fi("s3f", "Shift 3 Female", 'type="number"') +
    "</div></div>";
  var done = 0,
    tot = 0;
  FQ.forEach(function (q) {
    if (!q.n) return;
    tot++;
    var a = S.form.a[q.n];
    if (
      q.t === "t8" || q.t === "t34"
        ? S.fac.length
        : q.t === "g"
          ? a &&
            Object.keys(a).some(function (k) {
              return a[k];
            })
          : a !== undefined && !(a.length === 0)
    )
      done++;
  });
  h += '<div class="prog">' + done + " / " + tot + " ang nasagot</div>";
  FQ.forEach(function (q) {
    h += q.s ? "<h2>" + q.s + "</h2>" : qH(q);
  });
  h +=
    '<h2>Pirmahan</h2><div class="card"><p class="lbl">TWG Members (printed name)</p>' +
    fi("w1", "1") +
    fi("w2", "2") +
    fi("w3", "3") +
    fi("w4", "4") +
    '<div class="g" style="margin-top:8px">' +
    fi("pt", "Position Title (School Head)") +
    fi("sd", "Date", 'type="date"') +
    "</div></div>";
  return h;
}
function DK() {
  return Object.keys(S.days).filter(function (d) {
    return !fmo || d.slice(0, 7) === fmo;
  });
}
function mon(ym) {
  var M = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  return M[+ym.slice(5, 7) - 1] + " " + ym.slice(0, 4);
}
function fctl() {
  return (
    '<div class="noprint" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0"><div class="seg"><button class="y ' +
    (fper === "w" ? "on" : "") +
    '" data-a="fper" data-v="w">Linggo</button><button class="y ' +
    (fper === "m" ? "on" : "") +
    '" data-a="fper" data-v="m">Buwan</button></div>' +
    (fper === "m"
      ? '<input type="month" id="fmo" style="width:auto" value="' + (fmv || cur.slice(0, 7)) + '">'
      : "") +
    "</div>"
  );
}
function wle(w) {
  var M = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    a = new Date(w + "T00:00:00"),
    b = new Date(a);
  b.setDate(b.getDate() + 6);
  return (
    M[a.getMonth()] +
    " " +
    a.getDate() +
    " \u2013 " +
    (a.getMonth() !== b.getMonth() ? M[b.getMonth()] + " " : "") +
    b.getDate() +
    ", " +
    b.getFullYear()
  );
}
function repLines() {
  var L = [],
    F = S.form;
  L.push("DEPARTMENT OF EDUCATION \u2014 WASH IN SCHOOLS (WinS) MONITORING FORM");
  L.push(
    (fper === "m" ? "Month: " + mon(fmv || cur.slice(0, 7)) : "Week: " + wle(cur)) +
      " | School Year: " +
      hv("sy") +
      " | Level: " +
      hv("lv"),
  );
  L.push(
    "School: " +
      hv("sn") +
      " | School ID: " +
      hv("id") +
      " | District: " +
      hv("di") +
      " | Division: " +
      hv("dv"),
  );
  L.push("Address: " + hv("ad"));
  L.push("School Head: " + hv("hd") + " | Contact: " + hv("ct"));
  var tm = 0,
    tf = 0;
  ["s1", "s2", "s3"].forEach(function (s) {
    var m = +hv(s + "m") || 0,
      f = +hv(s + "f") || 0;
    tm += m;
    tf += f;
    L.push(
      "Enrolment " +
        s.replace("s", "Shift ") +
        ": Male " +
        (m || "") +
        ", Female " +
        (f || "") +
        ", Total " +
        (m + f || ""),
    );
  });
  FQ.forEach(function (q) {
    if (q.s) L.push("[" + q.s + "]");
    else L.push(q.n + ". " + q.q + " \u2192 " + txt(q, F.a[q.n]));
  });
  L.push(
    "TWG Members: " +
      [1, 2, 3, 4]
        .map(function (i) {
          return hv("w" + i);
        })
        .filter(Boolean)
        .join(", "),
  );
  L.push("School Head position: " + hv("pt") + " | Date: " + hv("sd"));
  return L;
}
function formRep() {
  fmo = fper === "m" ? fmv || cur.slice(0, 7) : "";
  var L = repLines(),
    h =
      '<div class="noprint"><button class="b p" data-a="print">\ud83d\udda8 I-print</button> <button class="b p" data-a="pdf">\u2b07 I-download bilang PDF</button></div>' +
      fctl() +
      '<div class="pr">' +
      statsH() +
      '</div><div class="card rep" style="margin-top:10px">';
  var i0 = 0;
  while (i0 < L.length && !/^\[/.test(L[i0])) i0++;
  h +=
    '<div class="fh"><div class="ft">' +
    esc(L[0] || "") +
    "</div>" +
    L.slice(1, i0)
      .map(function (l) {
        return '<div class="fi">' + esc(l) + "</div>";
      })
      .join("") +
    "</div>";
  L.slice(i0).forEach(function (l) {
    if (/^\[/.test(l)) {
      h += '<h2 class="fs">' + esc(l.slice(1, -1)) + "</h2>";
      return;
    }
    var m = l.match(/^(\d+[a-z]?)\.\s+([\s\S]*?)\s*\u2192\s*([\s\S]*)$/);
    if (m && (m[1] === "8" || m[3].indexOf(" | ") > -1)) return;
    if (m) {
      var e = /^[\u2014\-\s]*$/.test(m[3]);
      h +=
        '<div class="fr"><span class="qn">' +
        esc(m[1]) +
        '</span><span class="qt">' +
        esc(m[2]) +
        '</span><span class="qa' +
        (e ? " e" : "") +
        '">' +
        (e ? "\u2014" : esc(m[3])) +
        "</span></div>";
    } else h += '<div class="fr"><span class="qt">' + esc(l) + "</span></div>";
  });
  fmo = "";
  return (
    h +
    '</div><div class="card noprint"><p class="lbl">Kopyahin lahat ng nasa baba at i-send sa akin para magawan ko ng filled na Word form.</p><textarea rows="8" readonly>' +
    esc(L.join("\n")) +
    "</textarea></div>"
  );
}
function viewForm() {
  S.form = S.form || {};
  S.form.h = S.form.h || {};
  S.form.a = S.form.a || {};
  return (
    '<div class="seg noprint" style="justify-content:flex-start;margin-bottom:10px"><button class="b ' +
    (fm === "e" ? "p" : "") +
    '" data-a="fmode" data-v="e">Sagutan</button><button class="b ' +
    (fm === "r" ? "p" : "") +
    '" data-a="fmode" data-v="r">Report</button></div>' +
    (fm === "r" ? formRep() : formEdit())
  );
}
function nv(v) {
  return /^\d+$/.test(v) ? Number(v) : v;
}
document.addEventListener("click", function (e) {
  var b = e.target.closest("button[data-a]");
  if (!b) return;
  var a = b.getAttribute("data-a"),
    q = b.getAttribute("data-q"),
    v = b.getAttribute("data-v");
  if (!S.form) return;
  var A = S.form.a;
  if (a === "fmode") {
    fm = v;
    draw();
  } else if (a === "fper") {
    fper = v;
    draw();
  } else if (a === "fa") {
    v = nv(v);
    if (A[q] === v) delete A[q];
    else A[q] = v;
    save();
    draw();
  } else if (a === "fu") {
    A[q] = nv(v);
    save();
    draw();
  } else if (a === "fm") {
    var l = A[q] || [],
      i = +v,
      p = l.indexOf(i);
    if (p > -1) l.splice(p, 1);
    else l.push(i);
    A[q] = l;
    save();
    draw();
  } else if (a === "fc") {
    var o = A[q] || {},
      k = b.getAttribute("data-r") + "-" + b.getAttribute("data-c");
    o[k] = !o[k];
    A[q] = o;
    save();
    draw();
  } else if (a === "fl") {
    S.form.h.lv = v;
    save();
    draw();
  }
});
document.addEventListener("change", function (e) {
  var t = e.target;
  if (!S.form) return;
  if (t.id === "fmo") {
    fmv = t.value;
    draw();
  } else if (t.getAttribute("data-fq")) {
    var q = t.getAttribute("data-fq");
    if (t.value === "") delete S.form.a[q];
    else S.form.a[q] = Number(t.value);
    save();
    draw();
  } else if (t.getAttribute("data-fh")) {
    S.form.h[t.getAttribute("data-fh")] = t.value;
    save();
  }
});
