var KEY = "school-hub-v1",
  D = null;
try {
  D = JSON.parse(localStorage.getItem(KEY));
} catch (e) {}
D = D || {};
D.info = Object.assign(
  {
    school: "Potrero Elementary School",
    address: "4 Pinagtipunan Circle, Potrero, Malabon City",
    phone: "(02) 8478-3166",
    email: "potreroes.malaboncity@deped.gov.ph",
    schoolId: "",
    principal: "Elizabeth C. Aquino, PSDS / OIC - Principal",
    enrollment: "",
    teachers: "",
    classrooms: "",
    wins: "",
    testing: "",
    partnership: "",
    notes: "",
  },
  D.info || {},
);
D.sd = Object.assign(
  { coord: "", team: "", hazards: "", evac: "", warn: "", notes: "" },
  D.sd || {},
);
["fac", "contacts", "docs", "drills", "secs", "studs", "cal"].forEach(function (k) {
  D[k] = D[k] || [];
});
function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(D));
  } catch (e) {}
}
function $(s) {
  return document.querySelector(s);
}
function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
  });
}
function td(n) {
  var d = new Date();
  d.setDate(d.getDate() + (n || 0));
  return (
    d.getFullYear() +
    "-" +
    ("0" + (d.getMonth() + 1)).slice(-2) +
    "-" +
    ("0" + d.getDate()).slice(-2)
  );
}
function ago(s) {
  return s ? Math.floor((new Date(td()) - new Date(s)) / 864e5) : null;
}
var SC = {
  fac: {
    t: "facilities",
    hint: 'Ilista ang CR, handwashing (group at individual ay hiwalay), water source, classroom, atbp. Ang "Bilang" ang bumubuo sa count sa Overview.',
    f: [
      {
        k: "type",
        l: "Type",
        o: [
          "Restroom / CR",
          "Group handwashing",
          "Individual handwashing",
          "Water source",
          "Classroom",
          "Canteen",
          "Clinic",
          "Other",
        ],
      },
      { k: "name", l: "Pangalan / lokasyon", ph: "hal. Grade 1-3 Girls CR" },
      { k: "qty", l: "Bilang", t: "number", d: 1 },
      { k: "cond", l: "Condition", o: ["Good", "Needs repair", "Out of order"] },
      { k: "insp", l: "Huling inspection", t: "date" },
      { k: "note", l: "Notes" },
    ],
    cols: ["type", "name", "qty", "cond", "insp"],
  },
  cal: {
    t: "calendar/activities",
    hint: "Mga ganap sa school: activity, programa, meeting, exam, holiday. Pindutin ang petsa sa kalendaryo para doon mag-add.",
    f: [
      { k: "date", l: "Petsa (simula)", t: "date", d: "sel" },
      { k: "end", l: "Hanggang (kung ilang araw)", t: "date" },
      { k: "title", l: "Activity / ganap", ph: "hal. Nutrition Month Culmination" },
      { k: "type", l: "Uri", o: ["Activity", "Holiday / No class", "Meeting / Training", "Exam / Assessment", "WinS / Health", "Other"] },
      { k: "note", l: "Notes / lugar / sino" },
    ],
    cols: ["date", "end", "title", "type", "note"],
  },
  drills: {
    t: "sdrrm/drills",
    hint: "Log ng mga drill (earthquake, fire, atbp.).",
    f: [
      { k: "date", l: "Petsa", t: "date", d: "today" },
      { k: "type", l: "Uri", o: ["Earthquake", "Fire", "Flood", "Typhoon", "Other"] },
      { k: "part", l: "Participants / bilang" },
      { k: "note", l: "Remarks" },
    ],
    cols: ["date", "type", "part", "note"],
  },
  contacts: {
    t: "contacts",
    hint: "Mga numero at taong kailangan mo.",
    f: [
      { k: "name", l: "Pangalan / office" },
      { k: "role", l: "Position / role" },
      { k: "phone", l: "Telepono / mobile" },
      { k: "email", l: "Email" },
      { k: "note", l: "Notes" },
    ],
    cols: ["name", "role", "phone", "email"],
  },
  docs: {
    t: "documents",
    hint: "Incoming at outgoing na letters at memo.",
    f: [
      { k: "ctl", l: "Control no." },
      { k: "date", l: "Petsa", t: "date", d: "today" },
      { k: "dir", l: "Direction", o: ["Incoming", "Outgoing"] },
      { k: "party", l: "From / To" },
      { k: "subj", l: "Subject" },
      { k: "status", l: "Status", o: ["Pending", "Done", "Filed"] },
    ],
    cols: ["ctl", "date", "dir", "party", "subj", "status"],
  },
};
var MN = ["Enero", "Pebrero", "Marso", "Abril", "Mayo", "Hunyo", "Hulyo", "Agosto", "Setyembre", "Oktubre", "Nobyembre", "Disyembre"],
  MS = ["Ene", "Peb", "Mar", "Abr", "May", "Hun", "Hul", "Ago", "Set", "Okt", "Nob", "Dis"],
  DN = ["Lin", "Lun", "Mar", "Miy", "Huw", "Biy", "Sab"],
  calY = +td().slice(0, 4),
  calM = +td().slice(5, 7) - 1,
  calSel = td();
function p2(n) {
  return ("0" + n).slice(-2);
}
function calEnd(r) {
  return r.end && r.end >= r.date ? r.end : r.date;
}
function calOn(d) {
  return D.cal.filter(function (r) {
    return r.date && r.date <= d && calEnd(r) >= d;
  });
}
function calMonth(y, m) {
  var a = y + "-" + p2(m + 1) + "-01",
    b = y + "-" + p2(m + 1) + "-31";
  return D.cal
    .filter(function (r) {
      return r.date && r.date <= b && calEnd(r) >= a;
    })
    .sort(function (x, z) {
      return String(x.date).localeCompare(String(z.date));
    });
}
function calCls(t) {
  return t === "Holiday / No class" ? "bad" : t === "Meeting / Training" ? "wn" : t === "WinS / Health" ? "ok" : "";
}
function calD(s) {
  return MS[+s.slice(5, 7) - 1] + " " + +s.slice(8, 10);
}
function calRange(r) {
  return calD(r.date) + (r.end && r.end > r.date ? "-" + calD(r.end) : "");
}
function calGrid() {
  var f = new Date(calY, calM, 1).getDay(),
    n = new Date(calY, calM + 1, 0).getDate(),
    t = td(),
    h = "<tr>" + DN.map(function (x) { return "<th>" + x + "</th>"; }).join("") + "</tr><tr>",
    i;
  for (i = 0; i < f; i++) h += '<td class="cx"></td>';
  for (i = 1; i <= n; i++) {
    var s = calY + "-" + p2(calM + 1) + "-" + p2(i),
      ev = calOn(s);
    if ((f + i - 1) % 7 === 0 && i > 1) h += "</tr><tr>";
    h +=
      '<td class="cd' + (s === t ? " now" : "") + (s === calSel ? " sel" : "") + '" data-cd="' + s + '"><b>' + i + "</b>" +
      ev.slice(0, 2).map(function (r) { return '<i class="ev ' + calCls(r.type) + '">' + esc(r.title) + "</i>"; }).join("") +
      (ev.length > 2 ? '<i class="ev mu">+' + (ev.length - 2) + " pa</i>" : "") + "</td>";
  }
  for (i = (7 - ((f + n) % 7)) % 7; i > 0; i--) h += '<td class="cx"></td>';
  return h + "</tr>";
}
function calNav() {
  return win(
    "calendar --" + MN[calM].toLowerCase() + "-" + calY,
    '<div class="bar" style="margin:0 0 8px;align-items:center"><button class="btn" data-cm="-1">◀</button><button class="btn" data-cm="0">ngayon</button><button class="btn" data-cm="1">▶</button><b style="color:var(--g)">' +
      MN[calM] + " " + calY + '</b></div><div class="tw"><table class="cal">' + calGrid() +
      '</table></div><div class="mu" style="font-size:12px;margin-top:6px">// pindutin ang petsa para doon mag-add ng activity</div>',
  );
}
var TABS = [
  ["home", "overview"],
  ["info", "school-info"],
  ["secs", "sections"],
  ["fac", "facilities"],
  ["cal", "calendar"],
  ["contacts", "contacts"],
  ["docs", "documents"],
];
var tab = "home",
  edit = null,
  q = "";
function win(t, b) {
  return (
    '<div class="win"><div class="tb"><i></i><i></i><i></i><span>' +
    t +
    '</span></div><div class="bd">' +
    b +
    "</div></div>"
  );
}
function fld(f, v) {
  var id = "f_" + f.k;
  if (f.o)
    return (
      "<div><label>" +
      f.l +
      '</label><select id="' +
      id +
      '">' +
      f.o
        .map(function (o) {
          return "<option" + (o === v ? " selected" : "") + ">" + esc(o) + "</option>";
        })
        .join("") +
      "</select></div>"
    );
  return (
    "<div><label>" +
    f.l +
    '</label><input id="' +
    id +
    '" type="' +
    (f.t || "text") +
    '" value="' +
    esc(v) +
    '" placeholder="' +
    esc(f.ph || "") +
    '"></div>'
  );
}
function cell(k, r) {
  var v = r[k];
  if (v == null || v === "") return '<span class="mu">—</span>';
  if (k === "cond")
    return (
      '<span class="tag ' +
      (v === "Good" ? "ok" : v === "Needs repair" ? "wn" : "bad") +
      '">' +
      esc(v) +
      "</span>"
    );
  if (k === "type" && r.title != null)
    return '<span class="tag ' + calCls(v) + '">' + esc(v) + "</span>";
  if (k === "status")
    return '<span class="tag ' + (v === "Pending" ? "wn" : "ok") + '">' + esc(v) + "</span>";
  if (k === "grp" && v !== "General") return '<span class="tag bad">' + esc(v) + "</span>";
  return esc(v);
}
function qty(t) {
  return D.fac
    .filter(function (r) {
      return r.type === t;
    })
    .reduce(function (a, r) {
      return a + (+r.qty || 0);
    }, 0);
}
function home() {
  var I = D.info,
    d = function (v) {
      return v === "" || v == null ? "—" : esc(v);
    },
    dr = D.drills.slice().sort(function (a, b) {
      return String(b.date).localeCompare(String(a.date));
    });
  var bad = D.fac.filter(function (r) {
      return r.cond && r.cond !== "Good";
    }),
    old = D.fac.filter(function (r) {
      var a = ago(r.insp);
      return a === null || a > 30;
    });
  var K = [
    [qty("Restroom / CR"), "Restroom / CR"],
    [qty("Group handwashing"), "Group handwashing"],
    [qty("Individual handwashing"), "Individual handwashing"],
    [qty("Classroom") || d(I.classrooms), "Classrooms"],
    [I.enrollment ? d(I.enrollment) : tally(D.secs) || "—", "Enrollment"],
    [d(I.teachers), "Teachers"],
    [D.secs.length, "Sections"],
    [tally(D.secs), "Learners"],
  ];
  var L = function (t, a, fn) {
    return win(
      t,
      a.length ? "<ul>" + a.map(fn).join("") + "</ul>" : '<span class="mu">// wala</span>',
    );
  };
  return (
    '<div class="kp">' +
    K.map(function (k) {
      return '<div class="k"><b>' + k[0] + "</b><span>" + k[1] + "</span></div>";
    }).join("") +
    "</div>" +
    secCounts() +
    L("calendar/ngayong-" + MN[+td().slice(5, 7) - 1].toLowerCase(), calMonth(+td().slice(0, 4), +td().slice(5, 7) - 1), function (r) {
      return '<li><span class="mu">' + calRange(r) + "</span> " + esc(r.title) + ' <span class="tag ' + calCls(r.type) + '">' + esc(r.type) + "</span></li>";
    }) +
    L("alerts/facilities-may-problema", bad, function (r) {
      return (
        "<li>" +
        esc(r.name || r.type) +
        ' <span class="tag ' +
        (r.cond === "Needs repair" ? "wn" : "bad") +
        '">' +
        esc(r.cond) +
        "</span></li>"
      );
    }) +
    L("alerts/walang-inspection-30-araw", old, function (r) {
      return (
        "<li>" +
        esc(r.name || r.type) +
        ' <span class="mu">(' +
        (r.insp ? "huli " + esc(r.insp) : "walang record") +
        ")</span></li>"
      );
    }) +
    (D.fac.length || D.contacts.length
      ? ""
      : win(
          "readme.txt",
          '<span class="mu">// Wala pang laman. Simulan sa school-info, sections, at facilities.</span>',
        ))
  );
}
function list(k) {
  var s = SC[k],
    r = D[k].slice(),
    e =
      edit != null
        ? D[k].filter(function (x) {
            return x.id === edit;
          })[0]
        : null;
  r.sort(function (a, b) {
    return k === "docs" || k === "drills"
      ? String(b.date || "").localeCompare(String(a.date || ""))
      : 0;
  });
  if (k === "cal") r = calMonth(calY, calM);
  if (q)
    r = r.filter(function (x) {
      return JSON.stringify(x).toLowerCase().indexOf(q.toLowerCase()) >= 0;
    });
  var h = win(
    s.t + (e ? " --edit" : " --add"),
    '<div class="mu" style="font-size:12px;margin-bottom:8px">// ' +
      s.hint +
      '</div><div class="g">' +
      s.f
        .map(function (f) {
          var v = e ? e[f.k] : f.d === "today" ? td() : f.d === "sel" ? calSel : f.d;
          return fld(f, v == null ? "" : v);
        })
        .join("") +
      '</div><div class="bar"><button class="btn p" id="save">' +
      (e ? "update" : "add") +
      "</button>" +
      (e ? '<button class="btn" id="cancel">cancel</button>' : "") +
      "</div>",
  );
  h += win(
    s.t + " --list (" + r.length + ")",
    '<input id="q" placeholder="grep..." value="' +
      esc(q) +
      '" style="margin-bottom:8px"><div class="tw"><table><tr>' +
      s.cols
        .map(function (c) {
          return (
            "<th>" +
            s.f.filter(function (f) {
              return f.k === c;
            })[0].l +
            "</th>"
          );
        })
        .join("") +
      "<th></th></tr>" +
      r
        .map(function (x) {
          return (
            "<tr>" +
            s.cols
              .map(function (c) {
                return "<td>" + cell(c, x) + "</td>";
              })
              .join("") +
            '<td style="white-space:nowrap"><button class="btn" data-a="e" data-id="' +
            x.id +
            '">edit</button> <button class="btn d" data-a="x" data-id="' +
            x.id +
            '">rm</button></td></tr>'
          );
        })
        .join("") +
      (r.length ? "" : '<tr><td colspan="9" class="mu">// wala pang laman</td></tr>') +
      "</table></div>",
  );
  return h;
}
function info() {
  var F = [
    ["school", "Pangalan ng school"],
    ["address", "Address"],
    ["phone", "Telepono"],
    ["email", "Email"],
    ["schoolId", "School ID"],
    ["principal", "Principal"],
    ["enrollment", "Total enrollment"],
    ["teachers", "Bilang ng teachers"],
    ["classrooms", "Bilang ng classrooms"],
  ];
  return win(
    "school-info.conf",
    '<div class="g">' +
      F.map(function (f) {
        return (
          "<div><label>" +
          f[1] +
          '</label><input data-i="' +
          f[0] +
          '" value="' +
          esc(D.info[f[0]]) +
          '"></div>'
        );
      }).join("") +
      "</div>" +
      [
        ["wins", "WinS (Wash in Schools)"],
        ["testing", "School Testing"],
        ["partnership", "School Partnership"],
        ["notes", "Iba pang paalala"],
      ]
        .map(function (f) {
          return (
            '<label style="margin-top:10px">' +
            f[1] +
            '</label><textarea data-i="' +
            f[0] +
            '" rows="3">' +
            esc(D.info[f[0]]) +
            "</textarea>"
          );
        })
        .join("") +
      '<div class="mu" style="font-size:12px;margin-top:6px">// auto-save</div>',
  );
}
function sd() {
  var F = [
    ["coord", "SDRRM Coordinator", 1],
    ["team", "DRRM Team / mga may tungkulin (pangalan at role)", 3],
    ["hazards", "Mga hazard ng school (baha, lindol, sunog, atbp.)", 3],
    ["evac", "Evacuation area, ruta, at assembly point", 3],
    ["warn", "Early warning / alarm system (kampana, sirena, SMS)", 2],
    ["notes", "Iba pang paalala (supplies, first aid, plano)", 3],
  ];
  return (
    win(
      "sdrrm.conf",
      '<div class="mu" style="font-size:12px;margin-bottom:8px">// School Disaster Risk Reduction and Management. Idagdag ang drill log sa <b>sdrrm/drills</b> sa baba at ang hotlines sa <b>contacts</b> (group: SDRRM / Emergency).</div>' +
        F.map(function (f) {
          return (
            '<label style="margin-top:8px">' +
            f[1] +
            '</label><textarea data-s="' +
            f[0] +
            '" rows="' +
            f[2] +
            '">' +
            esc(D.sd[f[0]]) +
            "</textarea>"
          );
        }).join(""),
    ) + list("drills")
  );
}
function render() {
  $("#nav").innerHTML = TABS.map(function (t) {
    return (
      '<button data-t="' +
      t[0] +
      '" class="' +
      (t[0] === tab ? "on" : "") +
      '">./' +
      t[1] +
      "</button>"
    );
  }).join("");
  $("#sn").textContent = D.info.school;
  $("#pt").textContent = TABS.filter(function (t) {
    return t[0] === tab;
  })[0][1];
  $("#main").innerHTML =
    tab === "home"
      ? home()
      : tab === "info"
        ? info()
        : tab === "sd"
          ? sd()
          : tab === "secs"
            ? secs()
            : tab === "cal"
              ? calNav() + list("cal")
              : list(tab);
}
document.addEventListener("click", function (e) {
  var cd = e.target.closest("[data-cd]");
  if (cd) {
    calSel = cd.dataset.cd;
    edit = null;
    render();
    return;
  }
  var t = e.target.closest("button");
  if (!t) return;
  if (t.dataset.cm != null) {
    var n = +t.dataset.cm,
      now = td();
    if (!n) {
      calY = +now.slice(0, 4);
      calM = +now.slice(5, 7) - 1;
    } else {
      calM += n;
      if (calM < 0) (calM = 11), calY--;
      if (calM > 11) (calM = 0), calY++;
    }
    calSel = calY === +now.slice(0, 4) && calM === +now.slice(5, 7) - 1 ? now : calY + "-" + p2(calM + 1) + "-01";
    edit = null;
    render();
    return;
  }
  if (t.dataset.sa || t.dataset.x) {
    secClick(t);
    return;
  }
  if (t.dataset.t) {
    tab = t.dataset.t;
    edit = null;
    q = "";
    render();
    return;
  }
  var k = tab === "sd" ? "drills" : tab,
    id = t.dataset.id ? +t.dataset.id : null;
  if (t.id === "save") {
    var rec = {};
    SC[k].f.forEach(function (f) {
      rec[f.k] = $("#f_" + f.k).value;
    });
    if (k === "cal" && (!rec.date || !String(rec.title).trim())) {
      alert("Lagyan ng petsa at pangalan ng activity.");
      return;
    }
    if (edit != null) {
      D[k] = D[k].map(function (x) {
        return x.id === edit ? Object.assign(x, rec) : x;
      });
      edit = null;
    } else {
      rec.id = Date.now();
      D[k].push(rec);
    }
    save();
    render();
    return;
  }
  if (t.id === "cancel") {
    edit = null;
    render();
    return;
  }
  if (t.dataset.a === "e") {
    edit = id;
    render();
    window.scrollTo(0, 0);
    return;
  }
  if (t.dataset.a === "x") {
    if (confirm("Burahin?")) {
      D[k] = D[k].filter(function (x) {
        return x.id !== id;
      });
      save();
      render();
    }
    return;
  }
});
document.addEventListener("input", function (e) {
  var t = e.target;
  if (t.dataset && t.dataset.i) {
    D.info[t.dataset.i] = t.value;
    save();
    $("#sn").textContent = D.info.school;
  } else if (t.dataset && t.dataset.s) {
    D.sd[t.dataset.s] = t.value;
    save();
  } else if (t.id === "q") {
    q = t.value;
    var p = t.selectionStart;
    render();
    var n = $("#q");
    n.focus();
    n.setSelectionRange(p, p);
  }
});
/* ===== SECTIONS (total per section only) ===== */
var sEdit = null,
  lastId = 0;
var GR = ["Kinder", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];
var SF = [
  { k: "grade", l: "Grade level", o: GR },
  { k: "name", l: "Section name", ph: "hal. Sampaguita" },
  { k: "adviser", l: "Adviser", ph: "Pangalan ng teacher" },
  { k: "total", l: "Total na estudyante", t: "number", ph: "hal. 40" },
];
var MON = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
function nid() {
  var n = Date.now();
  if (n <= lastId) n = lastId + 1;
  lastId = n;
  return n;
}
function fdt(v) {
  var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || "");
  return m ? MON[+m[2] - 1] + " " + +m[3] + ", " + m[1] : v == null ? "" : String(v);
}
function num(s) {
  return Math.max(0, parseInt(s && s.total, 10) || 0);
}
function tally(l) {
  return l.reduce(function (a, s) {
    return a + num(s);
  }, 0);
}
/* fix ALL CAPS names */
function fixc(s) {
  s = String(s == null ? "" : s);
  if (!/\p{L}/u.test(s) || s !== s.toUpperCase()) return s;
  return s
    .toLowerCase()
    .replace(/(^|[\s\-\/(.])(\p{L})/gu, function (m, a, b) {
      return a + b.toUpperCase();
    })
    .replace(/\b(Ii|Iii|Iv)\b/g, function (x) {
      return x.toUpperCase();
    });
}
function migr() {
  D.fac.forEach(function (r) {
    if (r.type === "Handwashing facility") r.type = "Group handwashing";
  });
  D.secs.forEach(function (s) {
    s.name = fixc(s.name);
    if (s.adviser) s.adviser = fixc(s.adviser);
    if (s.total == null || s.total === "") {
      var n = D.studs.filter(function (x) {
        return x.sec === s.id;
      }).length;
      s.total = n ? String(n) : "";
    }
  });
}
function secSorted() {
  return D.secs.slice().sort(function (a, b) {
    return (
      GR.indexOf(a.grade) - GR.indexOf(b.grade) || String(a.name).localeCompare(String(b.name))
    );
  });
}
function secName(s) {
  return s.grade + " - " + s.name;
}
function isMulti(sc) {
  return sc === "all" || String(sc).indexOf("g:") === 0;
}
function secList(sc) {
  var a = secSorted();
  if (sc === "all") return a;
  if (String(sc).indexOf("g:") === 0)
    return a.filter(function (s) {
      return s.grade === String(sc).slice(2);
    });
  return a.filter(function (s) {
    return s.id === +sc;
  });
}
function ttl(sc) {
  var SL = secList(sc);
  return sc === "all"
    ? ["Enrollment per Section", "Number of learners in each section"]
    : isMulti(sc)
      ? [
          String(sc).slice(2) + " Enrollment",
          SL.length + " section" + (SL.length > 1 ? "s" : "") + "  |  " + tally(SL) + " learners",
        ]
      : ["Section Enrollment", secName(SL[0])];
}
function fnm(sc, only) {
  var SL = sc != null ? secList(sc) : [];
  var b =
    sc != null
      ? sc === "all"
        ? "Enrollment_per_Section"
        : isMulti(sc)
          ? String(sc).slice(2).replace(/\W+/g, "_") + "_Enrollment"
          : "Section_" + secName(SL[0]).replace(/\W+/g, "_")
      : only
        ? "SDRRM"
        : "School_Profile";
  return b + "_Potrero_ES_" + td();
}
function sumRows(l) {
  var gs = [],
    b = [];
  l.forEach(function (s) {
    if (gs.indexOf(s.grade) < 0) gs.push(s.grade);
  });
  gs.forEach(function (g) {
    var ss = l.filter(function (s) {
      return s.grade === g;
    });
    ss.forEach(function (s) {
      b.push([g, s.name, s.adviser || "", num(s)]);
    });
    if (gs.length > 1 && ss.length > 1) b.push(["", g + " total", "", tally(ss)]);
  });
  if (l.length > 1) b.push(["TOTAL", "", "", tally(l)]);
  return b;
}
function btns(id) {
  return (
    '<button class="btn" data-x="pdf" data-id="' +
    esc(id) +
    '">⬇ PDF</button> <button class="btn" data-x="doc" data-id="' +
    esc(id) +
    '">⬇ Word</button>'
  );
}
var gOpen = {};
var GC = {
  Kinder: "#f472b6",
  "Grade 1": "#fb923c",
  "Grade 2": "#facc15",
  "Grade 3": "#4ade80",
  "Grade 4": "#22d3ee",
  "Grade 5": "#a78bfa",
  "Grade 6": "#f87171",
};
function gcol(g) {
  return GC[g] || "#7d8fa3";
}
function gnames(all) {
  var gs = [];
  all.forEach(function (s) {
    if (gs.indexOf(s.grade) < 0) gs.push(s.grade);
  });
  return gs;
}
function gblock(g, ss, right, inner) {
  var o = !!gOpen[g];
  return (
    '<div class="gr" style="--gc:' +
    gcol(g) +
    '"><div class="gh"><button class="gbtn" data-sa="tg" data-g="' +
    esc(g) +
    '"><span class="car">' +
    (o ? "\u25BE" : "\u25B8") +
    "</span> <b>" +
    esc(g) +
    '</b> <span class="gm">' +
    ss.length +
    (ss.length > 1 ? " sections" : " section") +
    " \u00B7 " +
    tally(ss) +
    " learners</span></button>" +
    (right || "") +
    "</div>" +
    (o ? '<div class="gbody">' + inner + "</div>" : "") +
    "</div>"
  );
}
function gtools() {
  return '<div class="bar" style="margin:0 0 10px"><button class="btn" data-sa="gall" data-v="1">\u25BE expand all</button><button class="btn" data-sa="gall" data-v="0">\u25B8 collapse all</button></div>';
}
function tot0(s) {
  var n = num(s);
  return n === 0 ? '<span class="tag wn">0</span>' : "<b>" + n + "</b>";
}
function expWin() {
  var all = secSorted();
  if (!all.length) return "";
  var top =
    '<div class="gtot" style="margin:0 0 10px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><span><b>Lahat ng sections</b> <span class="mu">\u00B7 ' +
    tally(all) +
    ' learners</span></span><span style="white-space:nowrap">' +
    btns("all") +
    "</span></div>";
  var body = gnames(all)
    .map(function (g) {
      var ss = all.filter(function (s) {
        return s.grade === g;
      });
      var inner =
        '<div class="tw"><table><tr><th>Section</th><th>Total</th><th></th></tr>' +
        ss
          .map(function (s) {
            return (
              "<tr><td>" +
              esc(s.name) +
              "</td><td>" +
              num(s) +
              '</td><td style="white-space:nowrap;text-align:right">' +
              btns(String(s.id)) +
              "</td></tr>"
            );
          })
          .join("") +
        "</table></div>";
      return gblock(g, ss, '<span style="white-space:nowrap">' + btns("g:" + g) + "</span>", inner);
    })
    .join("");
  return win(
    "download --pdf --word",
    '<div class="mu" style="font-size:12px;margin-bottom:8px">// Download: lahat, buong grade level (nasa tabi ng grade), o isang section lang (buksan ang grade).</div>' +
      top +
      gtools() +
      body,
  );
}
function secCounts() {
  var all = secSorted();
  if (!all.length) return "";
  var body = gnames(all)
    .map(function (g) {
      var ss = all.filter(function (s) {
        return s.grade === g;
      });
      var inner =
        '<div class="tw"><table><tr><th>Section</th><th>Adviser</th><th>Total</th></tr>' +
        ss
          .map(function (s) {
            return (
              "<tr><td>" +
              esc(s.name) +
              "</td><td>" +
              (s.adviser ? esc(s.adviser) : '<span class="mu">\u2014</span>') +
              "</td><td>" +
              tot0(s) +
              "</td></tr>"
            );
          })
          .join("") +
        "</table></div>";
      return gblock(g, ss, "", inner);
    })
    .join("");
  return win(
    "bilang/per-section",
    gtools() +
      body +
      '<div class="gtot"><b>BUONG SCHOOL</b> \u00B7 ' +
      all.length +
      " sections \u00B7 <b>" +
      tally(all) +
      "</b> learners</div>",
  );
}
function secs() {
  var e =
      sEdit != null
        ? D.secs.filter(function (x) {
            return x.id === sEdit;
          })[0]
        : null,
    r = secSorted();
  var h = win(
    "sections" + (e ? " --edit" : " --add"),
    '<div class="mu" style="font-size:12px;margin-bottom:8px">// Isang section = isang hanay. Ilagay lang ang total na estudyante ng section.</div><div class="g">' +
      SF.map(function (f) {
        return fld(f, e ? e[f.k] : "");
      }).join("") +
      '</div><div class="bar"><button class="btn p" data-sa="saveSec">' +
      (e ? "update" : "add") +
      "</button>" +
      (e ? '<button class="btn" data-sa="cancelSec">cancel</button>' : "") +
      "</div>",
  );
  if (!r.length) {
    h += win("sections --list (0)", '<span class="mu">// wala pang section</span>');
  } else {
    h += win(
      "sections --list (" + r.length + ")",
      gtools() +
        gnames(r)
          .map(function (g) {
            var ss = r.filter(function (s) {
              return s.grade === g;
            });
            var inner =
              '<div class="tw"><table><tr><th>Section</th><th>Adviser</th><th>Total</th><th></th></tr>' +
              ss
                .map(function (s) {
                  return (
                    "<tr><td>" +
                    esc(s.name) +
                    "</td><td>" +
                    (s.adviser ? esc(s.adviser) : '<span class="mu">\u2014</span>') +
                    "</td><td>" +
                    tot0(s) +
                    '</td><td style="white-space:nowrap;text-align:right"><button class="btn" data-sa="editSec" data-id="' +
                    s.id +
                    '">edit</button> <button class="btn d" data-sa="delSec" data-id="' +
                    s.id +
                    '">rm</button></td></tr>'
                  );
                })
                .join("") +
              "</table></div>";
            return gblock(g, ss, "", inner);
          })
          .join("") +
        '<div class="gtot"><b>TOTAL</b> \u00B7 ' +
        r.length +
        " sections \u00B7 <b>" +
        tally(r) +
        "</b> learners</div>",
    );
  }
  return h + expWin();
}
function secClick(t) {
  var a = t.dataset.sa,
    id = t.dataset.id ? +t.dataset.id : null;
  if (a === "tg") {
    gOpen[t.dataset.g] = !gOpen[t.dataset.g];
    render();
    return;
  }
  if (a === "gall") {
    GR.forEach(function (g) {
      gOpen[g] = t.dataset.v === "1";
    });
    render();
    return;
  }
  if (t.dataset.x) {
    var sc = t.dataset.id;
    sc = isMulti(sc) ? sc : +sc;
    if (!secList(sc).length) {
      alert("Walang section na ma-export.");
      return;
    }
    if (t.dataset.x === "pdf") pdf(false, sc);
    else docx(sc);
    return;
  }
  if (a === "saveSec") {
    var rec = {};
    SF.forEach(function (f) {
      rec[f.k] = $("#f_" + f.k).value.trim();
    });
    rec.name = fixc(rec.name);
    rec.adviser = fixc(rec.adviser);
    if (!rec.name) {
      alert("Lagyan ng section name.");
      return;
    }
    rec.total = rec.total === "" ? "" : String(Math.max(0, parseInt(rec.total, 10) || 0));
    gOpen[rec.grade] = true;
    if (sEdit != null) {
      D.secs = D.secs.map(function (x) {
        return x.id === sEdit ? Object.assign(x, rec) : x;
      });
      sEdit = null;
    } else {
      rec.id = nid();
      D.secs.push(rec);
    }
    save();
    render();
    return;
  }
  if (a === "cancelSec") {
    sEdit = null;
    render();
    return;
  }
  if (a === "editSec") {
    sEdit = id;
    var es = D.secs.filter(function (x) {
      return x.id === id;
    })[0];
    if (es) gOpen[es.grade] = true;
    render();
    window.scrollTo(0, 0);
    return;
  }
  if (a === "delSec") {
    if (confirm("Burahin ang section?")) {
      D.secs = D.secs.filter(function (x) {
        return x.id !== id;
      });
      save();
      render();
    }
  }
}
document.addEventListener("keydown", function (e) {
  if (e.key === "Enter" && tab === "secs" && e.target.tagName === "INPUT") {
    e.preventDefault();
    secClick({ dataset: { sa: "saveSec" } });
  }
});

/* ===== WORD (.docx) WRITER ===== */
var NV = "14305C",
  MU = "6C757D",
  DA = "D6DDE6",
  SO = "F0F4F9";
function wr(t, o) {
  o = o || {};
  return (
    "<w:r><w:rPr>" +
    (o.b ? "<w:b/>" : "") +
    (o.i ? "<w:i/>" : "") +
    (o.c ? '<w:color w:val="' + o.c + '"/>' : "") +
    (o.sz ? '<w:sz w:val="' + Math.round(o.sz * 2) + '"/>' : "") +
    '</w:rPr><w:t xml:space="preserve">' +
    esc(t) +
    "</w:t></w:r>"
  );
}
function wp(r, o) {
  o = o || {};
  return (
    "<w:p><w:pPr>" +
    (o.keep ? "<w:keepNext/>" : "") +
    (o.pb ? "<w:pageBreakBefore/>" : "") +
    (o.bd
      ? '<w:pBdr><w:bottom w:val="single" w:sz="' +
        o.bd +
        '" w:space="4" w:color="' +
        (o.bc || NV) +
        '"/></w:pBdr>'
      : "") +
    '<w:spacing w:before="' +
    (o.sb || 0) +
    '" w:after="' +
    (o.sa || 0) +
    '"/>' +
    (o.al ? '<w:jc w:val="' + o.al + '"/>' : "") +
    "</w:pPr>" +
    (r || "") +
    "</w:p>"
  );
}
function wc(w, inner, fill) {
  return (
    '<w:tc><w:tcPr><w:tcW w:w="' +
    w +
    '" w:type="dxa"/>' +
    (fill ? '<w:shd w:val="clear" w:color="auto" w:fill="' + fill + '"/>' : "") +
    '<w:vAlign w:val="center"/></w:tcPr>' +
    inner +
    "</w:tc>"
  );
}
function wbd(sz, col) {
  return ["top", "left", "bottom", "right", "insideH", "insideV"]
    .map(function (b) {
      return "<w:" + b + ' w:val="single" w:sz="' + sz + '" w:space="0" w:color="' + col + '"/>';
    })
    .join("");
}
function wtp(tw, bd, mar) {
  return (
    '<w:tblPr><w:tblW w:w="' +
    tw +
    '" w:type="dxa"/>' +
    (bd ? "<w:tblBorders>" + bd + "</w:tblBorders>" : "") +
    '<w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="' +
    mar[0] +
    '" w:type="dxa"/><w:left w:w="' +
    mar[1] +
    '" w:type="dxa"/><w:bottom w:w="' +
    mar[0] +
    '" w:type="dxa"/><w:right w:w="' +
    mar[1] +
    '" w:type="dxa"/></w:tblCellMar></w:tblPr>'
  );
}
function wt(cols, head, rows, al, tot) {
  var tw = cols.reduce(function (a, b) {
    return a + b;
  }, 0);
  var x =
    "<w:tbl>" +
    wtp(tw, wbd(4, DA), [70, 110]) +
    "<w:tblGrid>" +
    cols
      .map(function (w) {
        return '<w:gridCol w:w="' + w + '"/>';
      })
      .join("") +
    "</w:tblGrid>";
  x +=
    "<w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>" +
    head
      .map(function (h, i) {
        return wc(cols[i], wp(wr(h, { b: 1, c: "FFFFFF", sz: 9 }), { al: al[i] }), NV);
      })
      .join("") +
    "</w:tr>";
  rows.forEach(function (r, j) {
    var t = tot && /total/i.test(r[0] + " " + r[1]),
      f = t ? SO : j % 2 ? "F8FAFC" : null;
    x +=
      "<w:tr><w:trPr><w:cantSplit/></w:trPr>" +
      r
        .map(function (v, i) {
          return wc(
            cols[i],
            wp(wr(String(v == null ? "" : v), { sz: 9.5, b: t }), { al: al[i] }),
            f,
          );
        })
        .join("") +
      "</w:tr>";
  });
  return x + "</w:tbl>" + wp("", { sa: 160 });
}
function wk(items) {
  var n = items.length,
    w = Math.floor(9638 / n);
  return (
    "<w:tbl>" +
    wtp(w * n, wbd(24, "FFFFFF"), [100, 140]) +
    "<w:tblGrid>" +
    items
      .map(function () {
        return '<w:gridCol w:w="' + w + '"/>';
      })
      .join("") +
    "</w:tblGrid><w:tr>" +
    items
      .map(function (k) {
        return wc(
          w,
          wp(wr(String(k[0]), { b: 1, sz: 16, c: NV })) +
            wp(wr(k[1].toUpperCase(), { sz: 7, c: MU })),
          SO,
        );
      })
      .join("") +
    "</w:tr></w:tbl>" +
    wp("", { sa: 160 })
  );
}
function wsig() {
  var P = D.info.principal,
    L = function (t) {
      return wp(wr(t, { sz: 7.5, c: MU }), { al: "center" });
    };
  return (
    wp("", { sa: 200 }) +
    "<w:tbl>" +
    wtp(9638, "", [40, 60]) +
    '<w:tblGrid><w:gridCol w:w="4300"/><w:gridCol w:w="1038"/><w:gridCol w:w="4300"/></w:tblGrid><w:tr><w:trPr><w:cantSplit/></w:trPr>' +
    wc(
      4300,
      wp(wr("Prepared by:", { sz: 8.5, c: MU })) +
        wp(wr(" ", { sz: 9 }), { sb: 600, bd: 6, bc: MU }) +
        L("Signature over printed name"),
    ) +
    wc(1038, wp("")) +
    wc(
      4300,
      wp(wr("Noted by:", { sz: 8.5, c: MU })) +
        wp(wr(String(P || " "), { b: 1, sz: 9 }), { sb: 600, al: "center", bd: 6, bc: MU }) +
        L("School Head"),
    ) +
    "</w:tr></w:tbl>" +
    wp("")
  );
}
function crc32(u) {
  var t = crc32.t;
  if (!t) {
    t = crc32.t = [];
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
  }
  var c2 = 0xffffffff;
  for (var i = 0; i < u.length; i++) c2 = t[(c2 ^ u[i]) & 255] ^ (c2 >>> 8);
  return (c2 ^ 0xffffffff) >>> 0;
}
function zip(files) {
  var enc = new TextEncoder(),
    parts = [],
    cd = [],
    off = 0;
  files.forEach(function (f) {
    var nb = enc.encode(f[0]),
      db = enc.encode(f[1]),
      crc = crc32(db),
      h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true);
    h.setUint16(4, 20, true);
    h.setUint16(6, 0x0800, true);
    h.setUint16(8, 0, true);
    h.setUint16(10, 0, true);
    h.setUint16(12, 0x21, true);
    h.setUint32(14, crc, true);
    h.setUint32(18, db.length, true);
    h.setUint32(22, db.length, true);
    h.setUint16(26, nb.length, true);
    h.setUint16(28, 0, true);
    parts.push(new Uint8Array(h.buffer), nb, db);
    var c = new DataView(new ArrayBuffer(46));
    c.setUint32(0, 0x02014b50, true);
    c.setUint16(4, 20, true);
    c.setUint16(6, 20, true);
    c.setUint16(8, 0x0800, true);
    c.setUint16(10, 0, true);
    c.setUint16(12, 0, true);
    c.setUint16(14, 0x21, true);
    c.setUint32(16, crc, true);
    c.setUint32(20, db.length, true);
    c.setUint32(24, db.length, true);
    c.setUint16(28, nb.length, true);
    c.setUint32(42, off, true);
    cd.push(new Uint8Array(c.buffer), nb);
    off += 30 + nb.length + db.length;
  });
  var cs = 0;
  cd.forEach(function (p) {
    cs += p.length;
  });
  var e = new DataView(new ArrayBuffer(22));
  e.setUint32(0, 0x06054b50, true);
  e.setUint16(8, files.length, true);
  e.setUint16(10, files.length, true);
  e.setUint32(12, cs, true);
  e.setUint32(16, off, true);
  return new Blob(parts.concat(cd, [new Uint8Array(e.buffer)]), {
    type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  });
}
function dlBlob(b, n) {
  var a = document.createElement("a");
  a.href = URL.createObjectURL(b);
  a.download = n;
  document.body.appendChild(a);
  a.click();
  a.remove();
}
function docx(sc) {
  var SL = secList(sc);
  if (!SL.length) return;
  var I = D.info,
    multi = isMulti(sc),
    cT = tally(SL),
    T0 = ttl(sc),
    b = "";
  b +=
    wp(wr("Republic of the Philippines", { sz: 9, c: MU }), { al: "center" }) +
    wp(wr("DEPARTMENT OF EDUCATION", { b: 1, sz: 11, c: NV }), { al: "center", sa: 40 }) +
    wp(wr(String(I.school || "").toUpperCase(), { b: 1, sz: 20, c: NV }), {
      al: "center",
      sa: 40,
    }) +
    wp(wr(String(I.address || ""), { sz: 9.5 }), { al: "center" }) +
    wp(wr([I.phone, I.email].filter(Boolean).join("   |   "), { sz: 9.5, c: MU }), {
      al: "center",
      sa: 120,
      bd: 12,
    }) +
    wp(wr(T0[0].toUpperCase(), { b: 1, sz: 15, c: NV }), { al: "center", sb: 240 }) +
    wp(wr(T0[1] + "   |   As of " + fdt(td()), { sz: 9, c: MU }), { al: "center", sa: 240 });
  b += wk(
    multi
      ? [
          [SL.length, "Sections"],
          [cT, "Learners"],
        ]
      : [[cT, "Total learners"]],
  );
  var H = function (t, pb) {
    return wp(wr(t.toUpperCase(), { b: 1, sz: 12, c: NV }), {
      keep: 1,
      pb: pb,
      sb: pb ? 0 : 200,
      sa: 60,
      bd: 8,
      bc: "C49A2A",
    });
  };
  b += H("Enrollment per Section");
  b += wt(
    [1300, 2400, 3938, 2000],
    ["Grade", "Section", "Adviser", "Total"],
    sumRows(SL),
    ["left", "left", "left", "center"],
    true,
  );

  var W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"',
    X = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  var doc =
    X +
    "<w:document " +
    W +
    ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>' +
    b +
    '<w:sectPr><w:footerReference w:type="default" r:id="rId2"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr></w:body></w:document>';
  var fr = '<w:rPr><w:color w:val="' + MU + '"/><w:sz w:val="15"/></w:rPr>';
  var ftr =
    X +
    "<w:ftr " +
    W +
    '><w:p><w:pPr><w:pBdr><w:top w:val="single" w:sz="4" w:space="6" w:color="' +
    DA +
    '"/></w:pBdr><w:tabs><w:tab w:val="right" w:pos="9638"/></w:tabs></w:pPr><w:r>' +
    fr +
    '<w:t xml:space="preserve">' +
    esc(I.school || "") +
    "   |   Generated " +
    fdt(td()) +
    "</w:t></w:r><w:r>" +
    fr +
    '<w:tab/><w:t xml:space="preserve">Page </w:t></w:r><w:fldSimple w:instr="PAGE"><w:r>' +
    fr +
    "<w:t>1</w:t></w:r></w:fldSimple><w:r>" +
    fr +
    '<w:t xml:space="preserve"> of </w:t></w:r><w:fldSimple w:instr="NUMPAGES"><w:r>' +
    fr +
    "<w:t>1</w:t></w:r></w:fldSimple></w:p></w:ftr>";
  var sty =
    X +
    "<w:styles " +
    W +
    '><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial" w:eastAsia="Arial"/><w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="259" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style></w:styles>';
  var R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    CT = "application/vnd.openxmlformats-officedocument.wordprocessingml.";
  var ct =
    X +
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="' +
    CT +
    'document.main+xml"/><Override PartName="/word/styles.xml" ContentType="' +
    CT +
    'styles+xml"/><Override PartName="/word/footer1.xml" ContentType="' +
    CT +
    'footer+xml"/></Types>';
  var rels =
    X +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' +
    R +
    '/officeDocument" Target="word/document.xml"/></Relationships>';
  var drels =
    X +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' +
    R +
    '/styles" Target="styles.xml"/><Relationship Id="rId2" Type="' +
    R +
    '/footer" Target="footer1.xml"/></Relationships>';
  dlBlob(
    zip([
      ["[Content_Types].xml", ct],
      ["_rels/.rels", rels],
      ["word/document.xml", doc],
      ["word/styles.xml", sty],
      ["word/footer1.xml", ftr],
      ["word/_rels/document.xml.rels", drels],
    ]),
    fnm(sc) + ".docx",
  );
}

function pdf(only, sc) {
  var d = new window.jspdf.jsPDF({ unit: "pt", format: "a4" }),
    W = d.internal.pageSize.getWidth(),
    PH = d.internal.pageSize.getHeight(),
    I = D.info,
    S = D.sd,
    M = 40,
    CW = W - 2 * M;
  var NAVY = [20, 48, 92],
    GOLD = [196, 154, 42],
    INK = [33, 37, 41],
    MUTED = [108, 117, 125],
    LINE = [214, 221, 230],
    SOFT = [240, 244, 249];
  var MO = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  function fd(v) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || "");
    return m ? MO[+m[2] - 1] + " " + +m[3] + ", " + m[1] : v == null ? "" : String(v);
  }
  function fill(c) {
    d.setFillColor(c[0], c[1], c[2]);
  }
  function ink(c) {
    d.setTextColor(c[0], c[1], c[2]);
  }
  function stroke(c) {
    d.setDrawColor(c[0], c[1], c[2]);
  }
  var cls = sc != null,
    multi = cls && isMulti(sc),
    SL = cls ? secList(sc) : [],
    cT = tally(SL),
    TT = cls ? ttl(sc) : null,
    title = cls ? TT[0] : only ? "SDRRM Report" : "School Profile Report",
    sub = cls
      ? TT[1]
      : only
        ? "School Disaster Risk Reduction and Management"
        : "School information, facilities, sections and enrollment";
  var y = 0,
    sec = 0;
  d.setProperties({
    title: title + " - " + I.school,
    subject: sub,
    author: I.school,
    creator: "School Monitoring Hub",
  });

  /* ---------- Letterhead ---------- */
  fill(NAVY);
  d.rect(0, 0, W, 10, "F");
  d.setFont("helvetica", "normal");
  d.setFontSize(8.5);
  ink(MUTED);
  d.text("Republic of the Philippines", W / 2, 36, { align: "center" });
  d.setFont("helvetica", "bold");
  d.setFontSize(10.5);
  ink(NAVY);
  d.text("DEPARTMENT OF EDUCATION", W / 2, 50, { align: "center" });
  d.setFontSize(20);
  var nm = d.splitTextToSize(String(I.school || "").toUpperCase(), CW);
  d.text(nm, W / 2, 76, { align: "center" });
  y = 76 + (nm.length - 1) * 23;
  d.setFont("helvetica", "normal");
  d.setFontSize(9);
  ink(INK);
  y += 16;
  d.text(d.splitTextToSize(String(I.address || ""), CW), W / 2, y, { align: "center" });
  ink(MUTED);
  y += 12;
  d.text([I.phone, I.email].filter(Boolean).join("   |   "), W / 2, y, { align: "center" });
  y += 12;
  fill(NAVY);
  d.rect(M, y, CW, 2, "F");
  fill(GOLD);
  d.rect(M, y + 3.5, CW, 0.8, "F");
  y += 30;
  d.setFont("helvetica", "bold");
  d.setFontSize(15);
  ink(NAVY);
  d.text(title.toUpperCase(), W / 2, y, { align: "center" });
  y += 14;
  d.setFont("helvetica", "normal");
  d.setFontSize(9);
  ink(MUTED);
  d.text(sub + "  |  As of " + fd(td()), W / 2, y, { align: "center" });
  y += 20;

  /* ---------- Helpers ---------- */
  function newPage() {
    d.addPage();
    y = 60;
  }
  function need(h) {
    if (y + h > PH - 60) newPage();
  }
  function qn(t) {
    return D.fac
      .filter(function (r) {
        return r.type === t;
      })
      .reduce(function (a, r) {
        return a + (+r.qty || 0);
      }, 0);
  }
  function KPI(items) {
    var g = 8,
      n = items.length,
      bw = (CW - g * (n - 1)) / n,
      h = 50;
    items.forEach(function (k, i) {
      var x = M + i * (bw + g),
        v = String(k[0] == null || k[0] === "" ? "-" : k[0]);
      fill(SOFT);
      d.rect(x, y, bw, h, "F");
      fill(NAVY);
      d.rect(x, y, 3, h, "F");
      d.setFont("helvetica", "bold");
      d.setFontSize(17);
      while (d.getTextWidth(v) > bw - 18 && d.getFontSize() > 8) d.setFontSize(d.getFontSize() - 1);
      ink(NAVY);
      d.text(v, x + 12, y + 24);
      d.setFont("helvetica", "normal");
      d.setFontSize(7);
      ink(MUTED);
      d.text(k[1].toUpperCase(), x + 12, y + 39);
    });
    y += h + 22;
  }
  function H(t) {
    need(90);
    sec++;
    d.setFont("helvetica", "bold");
    d.setFontSize(11.5);
    ink(NAVY);
    d.text(sec + ".  " + t.toUpperCase(), M, y);
    stroke(LINE);
    d.setLineWidth(0.8);
    d.line(M, y + 7, W - M, y + 7);
    fill(GOLD);
    d.rect(M, y + 6, 48, 2.4, "F");
    y += 22;
  }
  function E() {
    d.setFont("helvetica", "italic");
    d.setFontSize(9);
    ink(MUTED);
    d.text("No records encoded.", M + 2, y + 4);
    y += 30;
  }
  function T(h, b, o) {
    o = o || {};
    if (!b.length) {
      E();
      return;
    }
    d.autoTable({
      startY: y,
      head: h ? [h] : undefined,
      body: b,
      theme: "grid",
      margin: { top: 60, left: M, right: M, bottom: 56 },
      styles: {
        font: "helvetica",
        fontSize: 8.5,
        cellPadding: { top: 5.5, bottom: 5.5, left: 7, right: 7 },
        textColor: INK,
        lineColor: LINE,
        lineWidth: 0.5,
        valign: "middle",
        overflow: "linebreak",
      },
      headStyles: {
        fillColor: NAVY,
        textColor: 255,
        fontStyle: "bold",
        fontSize: 8,
        lineColor: NAVY,
      },
      alternateRowStyles: { fillColor: o.kv ? 255 : [248, 250, 252] },
      columnStyles: o.cs || {},
      didParseCell: o.dpc,
    });
    y = d.lastAutoTable.finalY + 24;
  }
  var KV = function (a) {
    return a
      .filter(function (r) {
        return r[1] !== "" && r[1] != null;
      })
      .map(function (r) {
        return [r[0], String(r[1])];
      });
  };
  var KVS = {
    0: { cellWidth: 135, fillColor: SOFT, textColor: NAVY, fontStyle: "bold", valign: "top" },
    1: { valign: "top" },
  };
  var GOOD = [22, 128, 74],
    WARN = [178, 106, 0],
    BAD = [190, 30, 45];
  function colorize(col, map) {
    return function (c) {
      if (c.section === "body" && c.column.index === col && map[c.cell.raw]) {
        c.cell.styles.textColor = map[c.cell.raw];
        c.cell.styles.fontStyle = "bold";
      }
    };
  }
  var drills = D.drills.slice().sort(function (a, b) {
    return String(b.date).localeCompare(String(a.date));
  });
  var em = D.contacts.filter(function (c) {
      return c.grp !== "General";
    }),
    gc = D.contacts.filter(function (c) {
      return c.grp === "General";
    });
  var CCS = { 1: { cellWidth: 105 }, 2: { cellWidth: 85 }, 3: { cellWidth: 150 } };
  var cRow = function (c) {
    return [c.name || "", c.role || "", c.phone || "", c.email || ""];
  };
  function sumTable(l) {
    var b = sumRows(l),
      tt = function (r) {
        return /total/i.test((r[0] || "") + " " + (r[1] || ""));
      };
    T(
      ["Grade", "Section", "Adviser", "Total"],
      b.map(function (r) {
        return r.map(function (v) {
          return String(v);
        });
      }),
      {
        cs: { 0: { cellWidth: 70 }, 1: { cellWidth: 140 }, 3: { cellWidth: 70, halign: "center" } },
        dpc: function (c) {
          if (c.section === "body" && tt(c.row.raw)) {
            c.cell.styles.fontStyle = "bold";
            c.cell.styles.fillColor = SOFT;
          }
        },
      },
    );
  }

  /* ---------- Summary ---------- */
  if (cls)
    KPI(
      multi
        ? [
            [SL.length, "Sections"],
            [cT, "Learners"],
          ]
        : [[cT, "Total learners"]],
    );
  else if (only)
    KPI([
      [D.drills.length, "Drills conducted"],
      [drills[0] ? fd(drills[0].date) : "-", "Last drill"],
      [em.length, "Emergency contacts"],
    ]);
  else
    KPI([
      [I.enrollment || tally(D.secs) || "", "Enrollment"],
      [I.teachers, "Teachers"],
      [qn("Classroom") || I.classrooms, "Classrooms"],
      [qn("Restroom / CR"), "Restrooms"],
      [qn("Group handwashing"), "Group HW"],
      [qn("Individual handwashing"), "Indiv. HW"],
      [
        D.fac.filter(function (r) {
          return r.cond && r.cond !== "Good";
        }).length,
        "Need repair",
      ],
    ]);

  /* ---------- Sections ---------- */
  if (cls) {
    H("Enrollment per Section");
    sumTable(SL);
  } else {
    if (!only) {
      H("School Profile");
      T(
        null,
        KV([
          ["School ID", I.schoolId],
          ["School Head", I.principal],
          ["Total Enrollment", I.enrollment],
          ["Number of Teachers", I.teachers],
          ["Number of Classrooms", I.classrooms],
          ["WinS (Wash in Schools)", I.wins],
          ["School Testing", I.testing],
          ["School Partnership", I.partnership],
          ["Remarks", I.notes],
        ]),
        { kv: 1, cs: KVS },
      );
      H("Facilities");
      T(
        ["Type", "Name / Location", "Qty", "Condition", "Last Inspected"],
        D.fac.map(function (r) {
          return [r.type, r.name || "", r.qty || "", r.cond || "", fd(r.insp) || "-"];
        }),
        {
          cs: {
            0: { cellWidth: 100 },
            2: { cellWidth: 36, halign: "center" },
            3: { cellWidth: 76 },
            4: { cellWidth: 112 },
          },
          dpc: colorize(3, { Good: GOOD, "Needs repair": WARN, "Out of order": BAD }),
        },
      );
      var ce = calMonth(calY, calM);
      if (ce.length) {
        H("School Calendar - " + MN[calM] + " " + calY);
        T(
          ["Date", "Activity", "Type", "Notes"],
          ce.map(function (r) {
            return [fd(r.date) + (r.end && r.end > r.date ? " - " + fd(r.end) : ""), r.title || "", r.type || "", r.note || ""];
          }),
          { cs: { 0: { cellWidth: 120 }, 2: { cellWidth: 100 } } },
        );
      }
      H("Class Sections");
      sumTable(secSorted());
    }
    if (!only) {
      H("Contacts Directory");
      T(["Name / Office", "Position / Role", "Phone", "Email"], D.contacts.map(cRow), { cs: CCS });
      H("Documents Log");
      T(
        ["Ctl No.", "Date", "Direction", "From / To", "Subject", "Status"],
        D.docs.map(function (r) {
          return [
            r.ctl || "",
            fd(r.date),
            r.dir || "",
            r.party || "",
            r.subj || "",
            r.status || "",
          ];
        }),
        {
          cs: {
            0: { cellWidth: 58 },
            1: { cellWidth: 92 },
            2: { cellWidth: 56 },
            3: { cellWidth: 100 },
            5: { cellWidth: 56 },
          },
          dpc: colorize(5, { Pending: WARN, Done: GOOD, Filed: GOOD }),
        },
      );
    }
  }
  /* ---------- Running header and footer ---------- */
  var n = d.getNumberOfPages();
  for (var i = 1; i <= n; i++) {
    d.setPage(i);
    if (i > 1) {
      fill(NAVY);
      d.rect(0, 0, W, 5, "F");
      d.setFont("helvetica", "bold");
      d.setFontSize(8);
      ink(NAVY);
      d.text(String(I.school || ""), M, 28);
      d.setFont("helvetica", "normal");
      ink(MUTED);
      d.text(title, W - M, 28, { align: "right" });
      stroke(LINE);
      d.setLineWidth(0.6);
      d.line(M, 36, W - M, 36);
    }
    stroke(LINE);
    d.setLineWidth(0.6);
    d.line(M, PH - 42, W - M, PH - 42);
    d.setFont("helvetica", "normal");
    d.setFontSize(7.5);
    ink(MUTED);
    d.text(String(I.school || "") + "   |   Generated " + fd(td()), M, PH - 28);
    d.text("Page " + i + " of " + n, W - M, PH - 28, { align: "right" });
  }
  d.save(fnm(sc, only) + ".pdf");
}
$("#pdfA").onclick = function () {
  pdf(false);
};
$("#exp").onclick = function () {
  var a = document.createElement("a");
  a.href = URL.createObjectURL(
    new Blob([JSON.stringify(D, null, 1)], { type: "application/json" }),
  );
  a.download = "synco-backup-" + td() + ".json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  $("#msg").textContent = "backup saved";
};
$("#imp").onclick = function () {
  $("#file").click();
};
$("#file").onchange = function (e) {
  var f = e.target.files[0];
  if (!f) return;
  var r = new FileReader();
  r.onload = function () {
    try {
      var x = JSON.parse(r.result);
      if (!x.info) throw 0;
      D = x;
      D.sd = D.sd || {};
      ["fac", "contacts", "docs", "drills", "secs", "studs", "cal"].forEach(function (k) {
        D[k] = D[k] || [];
      });
      migr();
      save();
      render();
      $("#msg").textContent = "restored";
    } catch (er) {
      $("#msg").textContent = "invalid file";
    }
  };
  r.readAsText(f);
};
migr();
save();
render();
