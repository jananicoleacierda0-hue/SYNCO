# SYNCO

Offline school system (Potrero Elementary School). Walang server, walang install.
**Buksan ang `index.html`** sa Chrome o Edge.

## Folder map

| Path | Ano ito |
| --- | --- |
| `index.html`, `css/shell.css`, `js/shell.js` | Taas na bar + switch ng dalawang app |
| `hub/` | **School Hub**: overview, school-info, sections, facilities (group/individual handwashing), calendar (storage key `cal` sa loob ng `school-hub-v1`), contacts, documents |
| `hub/hub.js` | Lahat ng logic ng Hub (data, tabs, PDF, Word export, backup/restore) |
| `hub/hub.css` | Itsura ng Hub |
| `wins/` | **WinS Tracker** |
| `wins/wins-main.js` | Data, storage, linggo / facilities / proof / buod |
| `wins/wins-form.js` | WinS Monitoring Form (Attachment 03) |
| `wins/wins.css`, `wins/wins-theme.css` | Orihinal na itsura + dark theme override |
| `lib/pdf-lib.js` | jsPDF at AutoTable (third-party, MIT, wag galawin) |
| `img/` | Logo at favicon |

## Debugging tips

1. Pindutin ang **F12** > **Console** para makita ang error (pulang linya + pangalan ng file at line).
2. Ang Hub at WinS ay tig-isang iframe. Sa DevTools, piliin sa taas ng Console ang tamang frame
   (`hub/index.html` o `wins/index.html`) bago mag-type ng command.
3. Saved data (localStorage): Hub = `school-hub-v1`, WinS = `wins2`.
   Para tingnan: Console > `localStorage.getItem("school-hub-v1")`.
4. Para i-reset ang isang app: `localStorage.removeItem("school-hub-v1")` (i-backup muna!).
5. Pagkatapos mag-edit ng file, i-refresh lang ang page (Ctrl+F5).
6. Huwag palitan ang storage keys sa itaas, mawawala ang lumang data.
